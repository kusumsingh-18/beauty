import React from 'react';
import { ArrowRight, Sparkles, ShieldCheck, Star, Camera, Compass, Award } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PRODUCTS, HERO_CAMPAIGN_IMG, TRYON_MODEL_IMG } from '../data/products';

export const HomePage: React.FC = () => {
  const { setCurrentPage, addToCart, setQuickViewProduct, setIsShadeMixerOpen } = useApp();

  const featuredProducts = PRODUCTS.slice(0, 3);

  return (
    <div className="space-y-24 sm:space-y-32 pb-24">
      {/* 1. Storefront Hero: Architectural Split Campaign */}
      <section className="relative bg-[#F4F1EA] border-b border-stone-200 overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 lg:py-24 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          {/* Left Text Column */}
          <div className="lg:col-span-6 space-y-6">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-stone-500">
              <span>Collection No. 04</span>
              <span aria-hidden="true">·</span>
              <span>Clean Dermatological Makeup</span>
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-editorial font-medium text-stone-900 leading-[1.08] tracking-tight">
              The luminous poetry of bare radiance.
            </h1>

            <p className="text-sm sm:text-base text-stone-600 leading-relaxed max-w-xl">
              High-purity botanical pigments suspended in cold-pressed plant squalane and barrier peptides. Designed to honor your natural skin tone with zero weight, zero flaking, and zero silicones.
            </p>

            <div className="pt-2 flex flex-wrap gap-4">
              <button
                onClick={() => setCurrentPage('shop')}
                className="px-6 py-3.5 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span>Shop The Collection</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setCurrentPage('tryon')}
                className="px-6 py-3.5 bg-white border border-stone-300 text-stone-900 text-xs uppercase tracking-widest font-semibold hover:bg-stone-50 transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Camera className="w-4 h-4 text-stone-700" />
                <span>Launch Virtual Studio</span>
              </button>
            </div>

            {/* Quiet trust markers */}
            <div className="pt-6 border-t border-stone-200/80 flex items-center gap-6 text-xs text-stone-500">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-stone-800" />
                <span>100% Silicone-Free</span>
              </div>
              <span aria-hidden="true">·</span>
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-800" />
                <span>Intelligent Tone Matching</span>
              </div>
            </div>
          </div>

          {/* Right Campaign Visual */}
          <div className="lg:col-span-6 relative">
            <div className="relative aspect-4/3 sm:aspect-16/9 lg:aspect-4/3 bg-stone-200 border border-stone-300/80 overflow-hidden shadow-lg">
              <img
                src={HERO_CAMPAIGN_IMG}
                alt="Aura Beauty Editorial Model"
                className="w-full h-full object-cover object-center"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-stone-900/40 via-transparent to-transparent pointer-events-none" />

              <div className="absolute bottom-4 left-4 right-4 bg-white/90 backdrop-blur-md p-3.5 border border-white/60 flex items-center justify-between">
                <div>
                  <p className="text-[10px] uppercase tracking-widest text-stone-500 font-semibold">Featured Campaign Look</p>
                  <p className="text-xs font-serif font-medium text-stone-900">Suede Rouge in Alabaster Rose + Lucent Glaze</p>
                </div>
                <button
                  onClick={() => setCurrentPage('tryon')}
                  className="px-3 py-1.5 bg-stone-900 text-white text-[11px] uppercase tracking-wider font-medium hover:bg-stone-800 cursor-pointer"
                >
                  Try Look
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. Featured Collection Grid: 3-column desktop baseline */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-12 gap-4 border-b border-stone-200 pb-6">
          <div>
            <span className="text-xs uppercase tracking-widest font-semibold text-stone-500">
              Curated Essentials
            </span>
            <h2 className="text-2xl sm:text-3xl font-editorial font-medium text-stone-900 mt-1">
              Atelier Best-Sellers
            </h2>
          </div>
          <button
            onClick={() => setCurrentPage('shop')}
            className="text-xs uppercase tracking-widest font-semibold text-stone-900 hover:underline flex items-center gap-1.5"
          >
            <span>View All Formulas</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {featuredProducts.map(product => (
            <div
              key={product.id}
              className="group bg-white border border-stone-200/80 p-5 flex flex-col justify-between transition-all duration-300 hover:-translate-y-1 hover:shadow-md"
            >
              <div>
                {/* Product Image Frame */}
                <div
                  onClick={() => setQuickViewProduct(product)}
                  className="aspect-4/3 bg-[#F9F9F8] overflow-hidden border border-stone-100 relative cursor-pointer"
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  {product.isBestSeller && (
                    <span className="absolute top-3 left-3 text-[10px] uppercase tracking-widest font-semibold bg-white/90 px-2 py-0.5 border border-stone-200 text-stone-800">
                      Cult Classic
                    </span>
                  )}
                </div>

                {/* Metadata */}
                <div className="mt-4 space-y-1.5">
                  <div className="flex items-center justify-between text-xs text-stone-500">
                    <span className="uppercase tracking-wider">{product.category}</span>
                    <span className="font-mono tabular-nums font-semibold text-stone-900">₹{product.price.toLocaleString('en-IN')}</span>
                  </div>

                  <h3
                    onClick={() => setQuickViewProduct(product)}
                    className="font-editorial text-lg font-semibold text-stone-900 leading-snug cursor-pointer group-hover:text-stone-700 transition-colors"
                  >
                    {product.name}
                  </h3>

                  <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
                    {product.subtitle}
                  </p>
                </div>

                {/* Shades Preview */}
                <div className="mt-4 pt-3 border-t border-stone-100 flex items-center gap-1.5">
                  {product.shades.slice(0, 5).map(shade => (
                    <span
                      key={shade.id}
                      className="w-3.5 h-3.5 rounded-full border border-stone-300"
                      style={{ backgroundColor: shade.hex }}
                      title={`${shade.name} (${shade.finish})`}
                    />
                  ))}
                  {product.shades.length > 5 && (
                    <span className="text-[11px] text-stone-400 font-mono">
                      +{product.shades.length - 5}
                    </span>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="mt-6 pt-4 border-t border-stone-100 grid grid-cols-2 gap-2">
                <button
                  onClick={() => addToCart(product, product.shades[0])}
                  className="py-2.5 bg-stone-900 text-white text-[11px] uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors cursor-pointer text-center"
                >
                  Quick Add
                </button>
                <button
                  onClick={() => setQuickViewProduct(product)}
                  className="py-2.5 bg-stone-100 text-stone-800 text-[11px] uppercase tracking-widest font-medium hover:bg-stone-200 transition-colors cursor-pointer text-center"
                >
                  Details
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Interactive Virtual Studio Spotlight: Interactive Preview */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#1C1917] text-stone-100 p-8 sm:p-12 lg:p-16 border border-stone-800 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          <div className="lg:col-span-6 space-y-6">
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-amber-500">
              <Camera className="w-3.5 h-3.5" />
              <span>Real-Time Color Matrix</span>
            </div>

            <h2 className="text-3xl sm:text-4xl font-editorial font-medium text-white leading-tight">
              Virtual Shade Atelier. Zero guessing, zero waste.
            </h2>

            <p className="text-stone-300 text-sm leading-relaxed">
              Test every shade of liquid velvet lip pigment, dewy cream blush, and silk foundation directly against your live camera feed or our diverse shade catalog. Our intelligent canvas rendering maps natural undertones and finish textures in real-time.
            </p>

            <div className="space-y-2 text-xs text-stone-300">
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                <span>Split Before / After slider comparison</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                <span>Dynamic finish controls: Matte, Satin, Dewy Gloss</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
                <span>1-Click direct look-to-bag transfer</span>
              </div>
            </div>

            <div className="pt-2 flex flex-wrap gap-3">
              <button
                onClick={() => setCurrentPage('tryon')}
                className="px-6 py-3.5 bg-stone-100 text-stone-900 text-xs uppercase tracking-widest font-semibold hover:bg-white transition-colors flex items-center gap-2 cursor-pointer"
              >
                <span>Launch Try-On Studio</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                onClick={() => setIsShadeMixerOpen(true)}
                className="px-6 py-3.5 bg-stone-900 border border-stone-700 text-stone-100 text-xs uppercase tracking-widest font-semibold hover:border-white transition-colors flex items-center gap-2 cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Custom Pigment Alchemy</span>
              </button>
            </div>
          </div>

          <div className="lg:col-span-6 flex justify-center">
            <div className="relative w-full max-w-md bg-stone-900 border border-stone-700 p-4 shadow-2xl">
              <div className="relative aspect-4/3 overflow-hidden bg-stone-950">
                <img
                  src={TRYON_MODEL_IMG}
                  alt="Virtual Try-On Simulation"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                />
                {/* Simulated split line overlay */}
                <div className="absolute top-0 bottom-0 left-1/2 w-0.5 bg-white shadow-lg pointer-events-none" />
                <div className="absolute top-3 left-3 bg-black/60 backdrop-blur-xs px-2 py-0.5 text-[10px] uppercase font-mono tracking-wider text-white">
                  Bare Skin
                </div>
                <div className="absolute top-3 right-3 bg-rose-950/80 backdrop-blur-xs px-2 py-0.5 text-[10px] uppercase font-mono tracking-wider text-rose-200">
                  Alabaster Rose Lip
                </div>
              </div>
              <p className="text-[11px] text-stone-400 text-center mt-3 font-mono">
                Interactive split-view test model · Live camera supported
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. Skin Diagnostic & Personalized Regimen Callout */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-[#FAF7F0] border border-stone-200 p-8 sm:p-12 grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="space-y-3">
            <span className="text-xs uppercase tracking-widest font-semibold text-stone-500">
              Step 01
            </span>
            <h3 className="font-editorial text-xl font-semibold text-stone-900">
              Skin Tone & Undertone Scan
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Identify whether your baseline is Cool, Warm, Olive, or Neutral with our optical analysis quiz.
            </p>
          </div>

          <div className="space-y-3">
            <span className="text-xs uppercase tracking-widest font-semibold text-stone-500">
              Step 02
            </span>
            <h3 className="font-editorial text-xl font-semibold text-stone-900">
              Clean Bio-Active Filter
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Target skin barrier concerns like dehydration, redness, or excess sebum with clinically paired ingredients.
            </p>
          </div>

          <div className="space-y-3">
            <span className="text-xs uppercase tracking-widest font-semibold text-stone-500">
              Step 03
            </span>
            <h3 className="font-editorial text-xl font-semibold text-stone-900">
              Bespoke 3-Piece Regimen
            </h3>
            <p className="text-xs text-stone-600 leading-relaxed">
              Receive your personalized routine with tailored shade matches and 15% bundled savings.
            </p>
            <button
              onClick={() => setCurrentPage('diagnostic')}
              className="text-xs font-semibold text-stone-900 uppercase tracking-wider underline pt-1 block hover:text-stone-700"
            >
              Take Diagnostic Quiz →
            </button>
          </div>
        </div>
      </section>

      {/* 5. Loyalty & Transparency Pillars */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="border border-stone-200 bg-white p-8 sm:p-10 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <div className="flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-amber-800">
              <Award className="w-4 h-4" />
              <span>Aura Glow Club</span>
            </div>
            <h3 className="text-xl sm:text-2xl font-editorial font-medium text-stone-900 mt-1">
              Earn rewards with every conscious beauty choice.
            </h3>
            <p className="text-xs text-stone-600 mt-1">
              Earn 1.25x points on every order, daily streak rewards, free full-size lipsticks, and real-time courier tracking.
            </p>
          </div>

          <button
            onClick={() => setCurrentPage('loyalty-orders')}
            className="px-6 py-3 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors whitespace-nowrap cursor-pointer shrink-0"
          >
            Access Glow Hub
          </button>
        </div>
      </section>
    </div>
  );
};
