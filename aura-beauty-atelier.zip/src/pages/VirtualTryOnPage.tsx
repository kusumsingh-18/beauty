import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  RefreshCw,
  Upload,
  Sparkles,
  Check,
  Download,
  ShoppingBag,
  Eye,
  Sliders,
  Layers,
  Sun,
  Flame,
  Lightbulb,
  MapPin
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PRODUCTS, TRYON_MODEL_IMG, HERO_CAMPAIGN_IMG } from '../data/products';
import { Shade, Product } from '../types';
import { sound } from '../utils/audio';

type LightingMode = 'studio' | 'golden_hour' | 'high_key' | 'candlelit';

export const VirtualTryOnPage: React.FC = () => {
  const { addToCart, setIsShadeMixerOpen } = useApp();

  // Selected Makeup categories
  const lipProduct = PRODUCTS.find(p => p.id === 'aura-velvet-lip') || PRODUCTS[0];
  const blushProduct = PRODUCTS.find(p => p.id === 'aura-melt-blush') || PRODUCTS[2];
  const highlightProduct = PRODUCTS.find(p => p.id === 'aura-glass-glaze') || PRODUCTS[3];

  const [activeTab, setActiveTab] = useState<'lips' | 'cheeks' | 'highlight'>('lips');
  const [selectedLipShade, setSelectedLipShade] = useState<Shade>(lipProduct.shades[0]);
  const [selectedBlushShade, setSelectedBlushShade] = useState<Shade | null>(blushProduct.shades[0]);
  const [selectedHighlightShade, setSelectedHighlightShade] = useState<Shade | null>(null);

  // Settings
  const [lipIntensity, setLipIntensity] = useState<number>(75);
  const [blushIntensity, setBlushIntensity] = useState<number>(60);
  const [finishType, setFinishType] = useState<'Velvet Matte' | 'Dewy Gloss' | 'Silk Satin'>('Velvet Matte');
  const [lightingMode, setLightingMode] = useState<LightingMode>('studio');
  const [showLandmarks, setShowLandmarks] = useState<boolean>(false);

  // Input source: 'preset' | 'camera' | 'upload'
  const [sourceMode, setSourceMode] = useState<'preset' | 'camera' | 'upload'>('preset');
  const [selectedPresetIndex, setSelectedPresetIndex] = useState<number>(0);
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Split before/after slider
  const [splitPosition, setSplitPosition] = useState<number>(50); // percentage

  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const presetModels = [
    { name: 'Model 01 · Natural Radiant', image: TRYON_MODEL_IMG, tone: 'Fair / Neutral' },
    { name: 'Model 02 · Golden Honey', image: HERO_CAMPAIGN_IMG, tone: 'Medium / Warm' }
  ];

  // Camera handling
  useEffect(() => {
    let stream: MediaStream | null = null;
    if (sourceMode === 'camera') {
      setCameraError(null);
      navigator.mediaDevices?.getUserMedia({ video: { width: 640, height: 480, facingMode: 'user' } })
        .then(s => {
          stream = s;
          if (videoRef.current) {
            videoRef.current.srcObject = s;
            videoRef.current.play();
            setCameraActive(true);
          }
        })
        .catch(err => {
          console.warn('Camera access denied or unavailable:', err);
          setCameraError('Camera access unavailable. Switched to studio test model.');
          setSourceMode('preset');
        });
    } else {
      if (videoRef.current && videoRef.current.srcObject) {
        const s = videoRef.current.srcObject as MediaStream;
        s.getTracks().forEach(t => t.stop());
        videoRef.current.srcObject = null;
      }
      setCameraActive(false);
    }

    return () => {
      if (stream) {
        stream.getTracks().forEach(t => t.stop());
      }
    };
  }, [sourceMode]);

  // Handle local photo upload
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setUploadedImage(url);
      setSourceMode('upload');
      sound.playChime();
    }
  };

  // Add individual or complete look to cart
  const handleAddLipLook = () => {
    sound.playChime();
    addToCart(lipProduct, selectedLipShade);
  };

  const handleAddFullLook = () => {
    sound.playChime();
    addToCart(lipProduct, selectedLipShade);
    if (selectedBlushShade) {
      addToCart(blushProduct, selectedBlushShade);
    }
    if (selectedHighlightShade) {
      addToCart(highlightProduct, selectedHighlightShade);
    }
  };

  // Export stamped high-res look snapshot
  const handleExportSnapshot = () => {
    sound.playChime();
    const canvas = document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 1000;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Fill background
    ctx.fillStyle = '#1C1917';
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    // Draw image
    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.src =
      sourceMode === 'upload' && uploadedImage
        ? uploadedImage
        : presetModels[selectedPresetIndex].image;

    img.onload = () => {
      ctx.drawImage(img, 40, 40, 720, 720);

      // Draw lip pigment overlay on export canvas
      ctx.save();
      ctx.globalCompositeOperation = 'multiply';
      ctx.fillStyle = selectedLipShade.hex;
      ctx.globalAlpha = (lipIntensity / 100) * 0.85;
      ctx.beginPath();
      ctx.ellipse(40 + 720 * 0.52, 40 + 720 * 0.62, 720 * 0.08, 720 * 0.04, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      // Draw editorial footer stamp
      ctx.fillStyle = '#FAF9F5';
      ctx.fillRect(40, 760, 720, 200);

      ctx.fillStyle = '#1C1917';
      ctx.font = 'bold 22px Georgia';
      ctx.fillText('AURA BEAUTY ATELIER · LOOK ARCHIVE', 65, 810);

      ctx.font = '14px sans-serif';
      ctx.fillStyle = '#57534E';
      ctx.fillText(`LIP VELVET: ${selectedLipShade.name} (${selectedLipShade.finish}) · HEX ${selectedLipShade.hex}`, 65, 845);
      if (selectedBlushShade) {
        ctx.fillText(`CHEEK BALM: ${selectedBlushShade.name} (${selectedBlushShade.finish}) · ${blushIntensity}% FLUSH`, 65, 875);
      }
      ctx.fillText(`LIGHTING SIMULATION: ${lightingMode.toUpperCase()} · 100% CLEAN BOTANICAL PIGMENTS`, 65, 905);

      // Download link
      const dataUrl = canvas.toDataURL('image/png');
      const a = document.createElement('a');
      a.href = dataUrl;
      a.download = `AURA_Look_${Date.now()}.png`;
      a.click();
    };
  };

  // Lighting Filter style
  const lightingFilters: Record<LightingMode, string> = {
    studio: 'brightness(1) contrast(1.02)',
    golden_hour: 'brightness(1.04) sepia(0.22) contrast(1.05)',
    high_key: 'brightness(1.08) contrast(1.06) saturate(1.04)',
    candlelit: 'brightness(0.96) sepia(0.35) contrast(1.08)'
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      {/* Studio Header */}
      <div className="border-b border-stone-200 pb-8 flex flex-col md:flex-row md:items-end justify-between gap-4">
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-stone-500">
            <span>Augmented Beauty Studio</span>
            <span aria-hidden="true">·</span>
            <span>Real-Time Optical Simulation</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-medium text-stone-900 leading-tight">
            Virtual Shade Atelier
          </h1>
          <p className="text-xs sm:text-sm text-stone-600 max-w-xl leading-relaxed">
            Test pigment saturation and surface sheen against natural lighting. Adjust the split slider to compare against unadorned skin.
          </p>
        </div>

        {/* Source and Tools Toggle */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={() => setIsShadeMixerOpen(true)}
            className="px-3.5 py-2 bg-[#FAF7F0] border border-stone-300 text-stone-900 text-xs uppercase tracking-wider font-semibold hover:border-stone-900 transition-colors flex items-center gap-1.5 cursor-pointer"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-700" />
            <span>Mix Custom Shade</span>
          </button>

          <div className="flex items-center gap-1 p-1 bg-white border border-stone-300">
            <button
              onClick={() => {
                sound.playClick();
                setSourceMode('preset');
              }}
              className={`px-3 py-1.5 text-xs uppercase tracking-wider font-medium cursor-pointer transition-colors ${
                sourceMode === 'preset' ? 'bg-stone-900 text-white' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              Studio Models
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setSourceMode('camera');
              }}
              className={`px-3 py-1.5 text-xs uppercase tracking-wider font-medium cursor-pointer transition-colors flex items-center gap-1.5 ${
                sourceMode === 'camera' ? 'bg-stone-900 text-white' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Camera className="w-3.5 h-3.5" />
              <span>Live Camera</span>
            </button>
            <button
              onClick={() => fileInputRef.current?.click()}
              className={`px-3 py-1.5 text-xs uppercase tracking-wider font-medium cursor-pointer transition-colors flex items-center gap-1.5 ${
                sourceMode === 'upload' ? 'bg-stone-900 text-white' : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Upload className="w-3.5 h-3.5" />
              <span>Upload Photo</span>
            </button>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleFileUpload}
              className="hidden"
            />
          </div>
        </div>
      </div>

      {cameraError && (
        <div className="p-3 bg-amber-50 border border-amber-200 text-amber-900 text-xs">
          {cameraError}
        </div>
      )}

      {/* Main Studio Viewport & Controls Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Viewport (Canvas / Camera / Split View) */}
        <div className="lg:col-span-7 bg-[#1C1917] p-4 sm:p-6 border border-stone-800 space-y-4">
          {/* Top Viewport Controls Bar: Lighting & Landmarks */}
          <div className="flex flex-wrap items-center justify-between text-xs text-stone-300 pb-2 border-b border-stone-800 gap-2">
            {/* Lighting Modes */}
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] uppercase tracking-wider text-stone-400 mr-1">Lighting:</span>
              <button
                onClick={() => {
                  sound.playClick();
                  setLightingMode('studio');
                }}
                className={`px-2 py-1 text-[11px] uppercase font-mono border transition-colors ${
                  lightingMode === 'studio' ? 'border-white bg-stone-800 text-white' : 'border-stone-800 text-stone-400 hover:text-white'
                }`}
              >
                Daylight
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  setLightingMode('golden_hour');
                }}
                className={`px-2 py-1 text-[11px] uppercase font-mono border transition-colors ${
                  lightingMode === 'golden_hour' ? 'border-amber-400 bg-amber-950 text-amber-200' : 'border-stone-800 text-stone-400 hover:text-white'
                }`}
              >
                Golden 3200K
              </button>
              <button
                onClick={() => {
                  sound.playClick();
                  setLightingMode('candlelit');
                }}
                className={`px-2 py-1 text-[11px] uppercase font-mono border transition-colors ${
                  lightingMode === 'candlelit' ? 'border-rose-400 bg-rose-950 text-rose-200' : 'border-stone-800 text-stone-400 hover:text-white'
                }`}
              >
                Candlelight
              </button>
            </div>

            {/* Landmarks toggle */}
            <div className="flex items-center gap-2">
              <button
                onClick={() => setShowLandmarks(prev => !prev)}
                className={`text-[11px] uppercase font-mono px-2 py-1 border transition-colors ${
                  showLandmarks ? 'border-amber-400 text-amber-300' : 'border-stone-700 text-stone-400'
                }`}
              >
                {showLandmarks ? '● Landmarks On' : '○ Landmarks Off'}
              </button>
            </div>
          </div>

          <div
            className="relative aspect-4/3 w-full bg-stone-950 overflow-hidden select-none transition-all duration-300"
            style={{ filter: lightingFilters[lightingMode] }}
          >
            {/* 1. Underlying Base Image / Video */}
            {sourceMode === 'camera' ? (
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover transform -scale-x-100"
              />
            ) : sourceMode === 'upload' && uploadedImage ? (
              <img
                src={uploadedImage}
                alt="Uploaded portrait"
                className="w-full h-full object-cover"
              />
            ) : (
              <img
                src={presetModels[selectedPresetIndex].image}
                alt="Studio portrait"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            )}

            {/* 2. Intelligent Real-Time Makeup Shade Layer (Positioned over lips & cheeks) */}
            <div
              className="absolute inset-0 pointer-events-none transition-all duration-300"
              style={{
                clipPath: `polygon(${splitPosition}% 0, 100% 0, 100% 100%, ${splitPosition}% 100%)`
              }}
            >
              {/* Lips Overlay Simulation */}
              <div
                className="absolute left-[45%] top-[60%] w-[16%] h-[8%] rounded-[50%_50%_60%_60%] blur-[2.5px] transition-all duration-300 mix-blend-multiply"
                style={{
                  backgroundColor: selectedLipShade.hex,
                  opacity: lipIntensity / 100
                }}
              />
              {/* Gloss finish sheen overlay */}
              {finishType === 'Dewy Gloss' && (
                <div
                  className="absolute left-[48%] top-[61%] w-[10%] h-[3%] rounded-full blur-[1.5px] bg-white mix-blend-screen opacity-50"
                />
              )}

              {/* Cheek Blush Overlay Left */}
              {selectedBlushShade && (
                <>
                  <div
                    className="absolute left-[28%] top-[48%] w-[18%] h-[12%] rounded-full blur-[16px] transition-all duration-300 mix-blend-multiply"
                    style={{
                      backgroundColor: selectedBlushShade.hex,
                      opacity: (blushIntensity / 100) * 0.7
                    }}
                  />
                  {/* Cheek Blush Right */}
                  <div
                    className="absolute right-[28%] top-[48%] w-[18%] h-[12%] rounded-full blur-[16px] transition-all duration-300 mix-blend-multiply"
                    style={{
                      backgroundColor: selectedBlushShade.hex,
                      opacity: (blushIntensity / 100) * 0.7
                    }}
                  />
                </>
              )}

              {/* Crystalline Highlighter Sheen */}
              {selectedHighlightShade && (
                <>
                  <div
                    className="absolute left-[30%] top-[44%] w-[14%] h-[6%] rounded-full blur-[8px] bg-amber-100 mix-blend-screen opacity-60"
                  />
                  <div
                    className="absolute right-[30%] top-[44%] w-[14%] h-[6%] rounded-full blur-[8px] bg-amber-100 mix-blend-screen opacity-60"
                  />
                </>
              )}
            </div>

            {/* Landmark Pins Overlay if active */}
            {showLandmarks && (
              <div className="absolute inset-0 pointer-events-none">
                <div className="absolute left-[52%] top-[63%] -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full border border-amber-400 bg-amber-300/40 animate-ping" />
                <div className="absolute left-[36%] top-[54%] -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full border border-rose-400 bg-rose-300/40" />
                <div className="absolute right-[36%] top-[54%] -translate-x-1/2 -translate-y-1/2 w-2.5 h-2.5 rounded-full border border-rose-400 bg-rose-300/40" />
              </div>
            )}

            {/* 3. Interactive Split Slider Handle */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-white shadow-2xl cursor-ew-resize pointer-events-none"
              style={{ left: `${splitPosition}%` }}
            >
              <div className="absolute top-1/2 -translate-y-1/2 -left-3.5 w-7 h-7 rounded-full bg-stone-900 border-2 border-white flex items-center justify-center text-white shadow-lg text-[9px] font-mono pointer-events-auto cursor-grab active:cursor-grabbing">
                ⇄
              </div>
            </div>

            {/* Split Drag Range Overlay */}
            <input
              type="range"
              min="0"
              max="100"
              value={splitPosition}
              onChange={e => setSplitPosition(Number(e.target.value))}
              className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-20"
              aria-label="Before after split slider"
            />

            {/* Badges */}
            <div className="absolute top-3 left-3 bg-black/70 backdrop-blur-xs px-2.5 py-1 text-[10px] uppercase font-mono tracking-wider text-stone-200">
              Bare Canvas
            </div>
            <div className="absolute top-3 right-3 bg-stone-900/90 backdrop-blur-xs px-2.5 py-1 text-[10px] uppercase font-mono tracking-wider text-white border border-stone-700">
              Aura Filter Applied
            </div>
          </div>

          {/* Model Switcher & Snapshot Download */}
          <div className="flex flex-col sm:flex-row items-center justify-between text-xs text-stone-400 pt-2 gap-3">
            {sourceMode === 'preset' ? (
              <div className="flex items-center gap-2">
                <span className="text-[11px] uppercase tracking-wider">Skin Baseline:</span>
                <div className="flex gap-2">
                  {presetModels.map((model, idx) => (
                    <button
                      key={idx}
                      onClick={() => {
                        sound.playClick();
                        setSelectedPresetIndex(idx);
                      }}
                      className={`px-2.5 py-1 text-[11px] font-medium border transition-colors ${
                        selectedPresetIndex === idx
                          ? 'border-white text-white bg-stone-800'
                          : 'border-stone-700 text-stone-400 hover:text-white'
                      }`}
                    >
                      {model.tone}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <span className="text-stone-400 text-xs">Live Source Active</span>
            )}

            <button
              onClick={handleExportSnapshot}
              className="px-3 py-1.5 bg-stone-800 hover:bg-stone-700 text-white text-[11px] uppercase tracking-wider font-semibold border border-stone-700 flex items-center gap-1.5 cursor-pointer transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Look Snapshot</span>
            </button>
          </div>
        </div>

        {/* Right Studio Controls Palette */}
        <div className="lg:col-span-5 bg-white border border-stone-200 p-6 space-y-6">
          {/* Tabs: Lips / Cheeks / Highlighter */}
          <div className="flex border-b border-stone-200">
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('lips');
              }}
              className={`flex-1 py-2.5 text-xs uppercase tracking-widest font-semibold text-center border-b-2 transition-colors cursor-pointer ${
                activeTab === 'lips'
                  ? 'border-stone-900 text-stone-900'
                  : 'border-transparent text-stone-400 hover:text-stone-700'
              }`}
            >
              1. Lips ({selectedLipShade.name})
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('cheeks');
              }}
              className={`flex-1 py-2.5 text-xs uppercase tracking-widest font-semibold text-center border-b-2 transition-colors cursor-pointer ${
                activeTab === 'cheeks'
                  ? 'border-stone-900 text-stone-900'
                  : 'border-transparent text-stone-400 hover:text-stone-700'
              }`}
            >
              2. Cheeks
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setActiveTab('highlight');
              }}
              className={`flex-1 py-2.5 text-xs uppercase tracking-widest font-semibold text-center border-b-2 transition-colors cursor-pointer ${
                activeTab === 'highlight'
                  ? 'border-stone-900 text-stone-900'
                  : 'border-transparent text-stone-400 hover:text-stone-700'
              }`}
            >
              3. Glaze
            </button>
          </div>

          {/* Tab 1: Lips */}
          {activeTab === 'lips' && (
            <div className="space-y-5">
              <div>
                <div className="flex justify-between items-baseline mb-2">
                  <span className="text-xs uppercase tracking-wider font-semibold text-stone-700">
                    Suede Rouge Shades
                  </span>
                  <span className="text-xs font-mono tabular-nums text-stone-900 font-semibold">
                    ₹{lipProduct.price.toLocaleString('en-IN')}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {lipProduct.shades.map(shade => {
                    const isSelected = selectedLipShade.id === shade.id;
                    return (
                      <button
                        key={shade.id}
                        onClick={() => {
                          sound.playClick();
                          setSelectedLipShade(shade);
                        }}
                        className={`p-2.5 text-left border flex items-center gap-2.5 transition-all cursor-pointer ${
                          isSelected
                            ? 'border-stone-900 bg-[#FAF9F5] shadow-xs'
                            : 'border-stone-200 hover:border-stone-400'
                        }`}
                      >
                        <span
                          className="w-5 h-5 rounded-full border border-stone-300 shrink-0"
                          style={{ backgroundColor: shade.hex }}
                        />
                        <div className="overflow-hidden">
                          <p className="text-xs font-medium text-stone-900 truncate">{shade.name}</p>
                          <p className="text-[10px] text-stone-500">{shade.finish}</p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Intensity Slider */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-stone-600">Pigment Intensity</span>
                  <span className="font-mono tabular-nums text-stone-900">{lipIntensity}%</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="100"
                  value={lipIntensity}
                  onChange={e => setLipIntensity(Number(e.target.value))}
                  className="w-full accent-stone-900 cursor-pointer"
                />
              </div>

              {/* Finish Selector */}
              <div className="space-y-2">
                <span className="text-xs text-stone-600 block">Surface Sheen:</span>
                <div className="grid grid-cols-3 gap-2">
                  {(['Velvet Matte', 'Dewy Gloss', 'Silk Satin'] as const).map(f => (
                    <button
                      key={f}
                      onClick={() => {
                        sound.playClick();
                        setFinishType(f);
                      }}
                      className={`py-1.5 text-[11px] font-medium border text-center transition-colors cursor-pointer ${
                        finishType === f
                          ? 'border-stone-900 bg-stone-900 text-white'
                          : 'border-stone-200 text-stone-600 hover:border-stone-400'
                      }`}
                    >
                      {f}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Tab 2: Cheeks */}
          {activeTab === 'cheeks' && (
            <div className="space-y-5">
              <div>
                <div className="flex justify-between items-baseline mb-2">
                  <span className="text-xs uppercase tracking-wider font-semibold text-stone-700">
                    Petal Flush Balm Shades
                  </span>
                  <span className="text-xs font-mono tabular-nums text-stone-900 font-semibold">
                    ₹{blushProduct.price.toLocaleString('en-IN')}
                  </span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  {blushProduct.shades.map(shade => {
                    const isSelected = selectedBlushShade?.id === shade.id;
                    return (
                      <button
                        key={shade.id}
                        onClick={() => {
                          sound.playClick();
                          setSelectedBlushShade(shade);
                        }}
                        className={`p-2.5 text-left border flex items-center gap-2.5 transition-all cursor-pointer ${
                          isSelected
                            ? 'border-stone-900 bg-[#FAF9F5] shadow-xs'
                            : 'border-stone-200 hover:border-stone-400'
                        }`}
                      >
                        <span
                          className="w-5 h-5 rounded-full border border-stone-300 shrink-0"
                          style={{ backgroundColor: shade.hex }}
                        />
                        <div className="overflow-hidden">
                          <p className="text-xs font-medium text-stone-900 truncate">{shade.name}</p>
                          <p className="text-[10px] text-stone-500">{shade.finish}</p>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Blush Intensity */}
              <div className="space-y-2">
                <div className="flex justify-between text-xs">
                  <span className="text-stone-600">Cheek Flush Opacity</span>
                  <span className="font-mono tabular-nums text-stone-900">{blushIntensity}%</span>
                </div>
                <input
                  type="range"
                  min="20"
                  max="100"
                  value={blushIntensity}
                  onChange={e => setBlushIntensity(Number(e.target.value))}
                  className="w-full accent-stone-900 cursor-pointer"
                />
              </div>
            </div>
          )}

          {/* Tab 3: Highlighter */}
          {activeTab === 'highlight' && (
            <div className="space-y-5">
              <div>
                <div className="flex justify-between items-baseline mb-2">
                  <span className="text-xs uppercase tracking-wider font-semibold text-stone-700">
                    Lucent Crystalline Glaze
                  </span>
                  <span className="text-xs font-mono tabular-nums text-stone-900 font-semibold">
                    ₹{highlightProduct.price.toLocaleString('en-IN')}
                  </span>
                </div>

                <div className="grid grid-cols-1 gap-2">
                  {highlightProduct.shades.map(shade => {
                    const isSelected = selectedHighlightShade?.id === shade.id;
                    return (
                      <button
                        key={shade.id}
                        onClick={() => {
                          sound.playClick();
                          setSelectedHighlightShade(isSelected ? null : shade);
                        }}
                        className={`p-2.5 text-left border flex items-center gap-2.5 transition-all cursor-pointer ${
                          isSelected
                            ? 'border-stone-900 bg-[#FAF9F5] shadow-xs'
                            : 'border-stone-200 hover:border-stone-400'
                        }`}
                      >
                        <span
                          className="w-5 h-5 rounded-full border border-stone-300 shrink-0"
                          style={{ backgroundColor: shade.hex }}
                        />
                        <div className="flex-1">
                          <p className="text-xs font-medium text-stone-900">{shade.name}</p>
                          <p className="text-[10px] text-stone-500">{shade.finish}</p>
                        </div>
                        {isSelected && <Check className="w-3.5 h-3.5 text-stone-900" />}
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          )}

          {/* Actions & Add to Bag */}
          <div className="pt-4 border-t border-stone-200 space-y-2.5">
            <button
              onClick={handleAddLipLook}
              className="w-full py-3 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <ShoppingBag className="w-4 h-4" />
              <span>Add Lipstick to Bag ({selectedLipShade.name} · ₹{lipProduct.price.toLocaleString('en-IN')})</span>
            </button>

            <button
              onClick={handleAddFullLook}
              className="w-full py-2.5 bg-[#FAF7F0] border border-stone-300 text-stone-900 text-xs uppercase tracking-wider font-semibold hover:bg-stone-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-700" />
              <span>Add Complete Curated Look (Bundle 10% Off)</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
