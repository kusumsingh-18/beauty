import React, { useState } from 'react';
import {
  Sparkles,
  Check,
  ArrowRight,
  ShieldCheck,
  RefreshCw,
  ShoppingBag,
  Droplets,
  Heart,
  Bot,
  Send,
  Camera,
  MessageSquare,
  HelpCircle,
  Leaf
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PRODUCTS } from '../data/products';
import { SkinToneCategory, Undertone, SkinType, SkinDiagnosticResult, Product, Shade } from '../types';
import { sound } from '../utils/audio';

export const DiagnosticPage: React.FC = () => {
  const { userSkinProfile, setUserSkinProfile, addToCart, setCurrentPage, setSelectedIngredientForModal } = useApp();

  const [step, setStep] = useState<number>(1);
  const [selectedSkinTone, setSelectedSkinTone] = useState<SkinToneCategory>('Light');
  const [selectedUndertone, setSelectedUndertone] = useState<Undertone>('Neutral');
  const [selectedSkinType, setSelectedSkinType] = useState<SkinType>('Combination');
  const [selectedConcerns, setSelectedConcerns] = useState<string[]>(['Dehydration & Dullness']);

  // AI Dermatological Consultation State
  const [aiQuestion, setAiQuestion] = useState<string>('');
  const [isAiConsulting, setIsAiConsulting] = useState<boolean>(false);
  const [aiResponse, setAiResponse] = useState<{ query: string; answer: string; recommendedIngredient: string } | null>({
    query: 'Which formula protects against mid-day dehydration without clogging pores?',
    answer: 'Our Cellular Prime Hydrating Nectar pairs bio-identical Ceramide NP with olive squalane (422 Da). It integrates directly into the stratum corneum without dimethicone or synthetic waxes, guaranteeing 14-hour lipid retention.',
    recommendedIngredient: 'Olive-Derived Squalane'
  });

  const toneOptions: { tone: SkinToneCategory; label: string; desc: string; sampleHex: string }[] = [
    { tone: 'Fair', label: 'Fair Alabaster', desc: 'Porcelain, burns quickly in strong sun', sampleHex: '#F6E6DA' },
    { tone: 'Light', label: 'Light Ivory / Buff', desc: 'Light complexion with subtle golden or pink tint', sampleHex: '#EED9C3' },
    { tone: 'Medium', label: 'Medium Honey', desc: 'Warm beige, golden olive, tans easily', sampleHex: '#D1AC84' },
    { tone: 'Tan', label: 'Caramel & Tan', desc: 'Sun-kissed bronze, rarely burns', sampleHex: '#B2825A' },
    { tone: 'Deep', label: 'Deep Espresso', desc: 'Rich espresso, chestnut, golden undertone', sampleHex: '#6F472B' },
    { tone: 'Rich', label: 'Rich Obsidian', desc: 'Deepest neutral or warm ebony tones', sampleHex: '#3E2519' }
  ];

  const undertoneOptions: { undertone: Undertone; title: string; guide: string }[] = [
    {
      undertone: 'Cool',
      title: 'Cool Undertone',
      guide: 'Veins appear blue/purple. Silver jewelry compliments skin. Rosy or pink natural blush.'
    },
    {
      undertone: 'Neutral',
      title: 'Neutral Undertone',
      guide: 'Veins appear blue-green. Both gold and silver jewelry look balanced. Equal balance of warmth and pink.'
    },
    {
      undertone: 'Warm',
      title: 'Warm Undertone',
      guide: 'Veins appear greenish. Yellow gold jewelry glows best. Golden, peach, or peachy-yellow baseline.'
    },
    {
      undertone: 'Olive',
      title: 'Olive Undertone',
      guide: 'Subtle greenish-grey or golden cast. Neutralizing redness and ashiness brings out radiant vitality.'
    }
  ];

  const skinTypeOptions: { type: SkinType; title: string; desc: string }[] = [
    { type: 'Normal', title: 'Balanced Normal', desc: 'Even texture, rare breakouts, balanced oil and hydration.' },
    { type: 'Dry', title: 'Dry & Tight', desc: 'Craves lipid moisture, occasional flakiness, matte dullness.' },
    { type: 'Combination', title: 'Combination', desc: 'Oily T-zone (forehead, nose) with dry or normal cheeks.' },
    { type: 'Oily', title: 'Oily / Sebum-Prone', desc: 'Luminous shine develops mid-day, enlarged visible pores.' },
    { type: 'Sensitive', title: 'Reactive / Sensitive', desc: 'Easily turns red, stings with fragrances, fragile barrier.' }
  ];

  const concernOptions = [
    'Dehydration & Dullness',
    'Texture & Visible Pores',
    'Redness & Reactive Flushing',
    'Fine Lines & Loss of Elasticity',
    'Uneven Pigmentation'
  ];

  const handleToggleConcern = (concern: string) => {
    sound.playClick();
    setSelectedConcerns(prev =>
      prev.includes(concern)
        ? prev.filter(c => c !== concern)
        : [...prev, concern]
    );
  };

  const handleGeneratePrescription = () => {
    sound.playChime();
    const result: SkinDiagnosticResult = {
      skinTone: selectedSkinTone,
      undertone: selectedUndertone,
      skinType: selectedSkinType,
      concerns: selectedConcerns,
      recommendedProductIds: ['aura-silk-foundation', 'aura-velvet-lip', 'aura-melt-blush'],
      customRoutine: [
        {
          step: 1,
          title: 'Prime & Strengthen',
          productName: 'Cellular Prime Hydrating Nectar',
          reason: `Bio-identical ceramides prep your ${selectedSkinType.toLowerCase()} barrier for seamless pigment glide.`
        },
        {
          step: 2,
          title: 'Second-Skin Coverage',
          productName: `Skin Luminary Serum Foundation (Tone ${selectedSkinTone})`,
          reason: `Formulated with 4% Niacinamide to soothe ${selectedConcerns[0] || 'imperfections'} and match your ${selectedUndertone.toLowerCase()} undertone.`
        },
        {
          step: 3,
          title: 'Monochromatic Flush',
          productName: 'Petal Flush Nourishing Cream Pot',
          reason: `Rosehip antioxidants bring dimensional, non-comedogenic color to cheeks and lips.`
        }
      ]
    };

    setUserSkinProfile(result);
    setStep(5);
  };

  const handleAskAiConsultant = (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuestion.trim()) return;
    sound.playClick();
    setIsAiConsulting(true);

    const questionText = aiQuestion;
    setAiQuestion('');

    setTimeout(() => {
      sound.playChime();
      setIsAiConsulting(false);
      let answer = '';
      let recommendedIngredient = 'Olive-Derived Squalane';

      const q = questionText.toLowerCase();
      if (q.includes('acne') || q.includes('pore') || q.includes('oil')) {
        answer =
          'For oily or breakout-prone skin, our Skin Luminary Foundation features 4% pharmaceutical Niacinamide and non-nano zinc oxide with zero dimethicone, allowing pores to breathe while reducing sebum production by up to 68%.';
        recommendedIngredient = '4% Niacinamide (Vitamin B3)';
      } else if (q.includes('wrinkle') || q.includes('line') || q.includes('age') || q.includes('crease')) {
        answer =
          'Our formulas replace drying alcohol carriers with Hexapeptide-8 and 1% botanical bakuchiol, which gently smooth dynamic expression lines around lips and eyes without inducing peeling or irritation.';
        recommendedIngredient = 'Hexapeptide-8 Complex';
      } else if (q.includes('lip') || q.includes('chap') || q.includes('dry')) {
        answer =
          'Suede Rouge Botanical Liquid Velvet is suspended in micro-encapsulated hyaluronic acid spheres and organic squalane. It provides rich matte pigment payoff that continuously moisturizes for 12 hours.';
        recommendedIngredient = 'Hyaluronic Acid Spheres';
      } else {
        answer = `Based on your ${selectedSkinTone} complexion and ${selectedUndertone} undertone, our clean micro-milled mineral pigments reflect 360° natural ambient light without chalky ashiness or orange oxidation.`;
        recommendedIngredient = 'Organic Cold-Pressed Rosehip Seed Oil';
      }

      setAiResponse({
        query: questionText,
        answer,
        recommendedIngredient
      });
    }, 700);
  };

  // Matched products based on diagnosis
  const foundationProduct = PRODUCTS.find(p => p.id === 'aura-silk-foundation')!;
  const matchedFoundationShade =
    foundationProduct.shades.find(s => s.skinToneMatch?.includes(selectedSkinTone)) ||
    foundationProduct.shades[1];

  const lipProduct = PRODUCTS.find(p => p.id === 'aura-velvet-lip')!;
  const matchedLipShade =
    lipProduct.shades.find(s => s.skinToneMatch?.includes(selectedSkinTone)) ||
    lipProduct.shades[0];

  const blushProduct = PRODUCTS.find(p => p.id === 'aura-melt-blush')!;
  const matchedBlushShade =
    blushProduct.shades.find(s => s.skinToneMatch?.includes(selectedSkinTone)) ||
    blushProduct.shades[0];

  const handleAddFullPrescription = () => {
    sound.playChime();
    addToCart(foundationProduct, matchedFoundationShade);
    addToCart(lipProduct, matchedLipShade);
    addToCart(blushProduct, matchedBlushShade);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-12">
      {/* Title */}
      <div className="text-center space-y-3 max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-stone-500">
          <Sparkles className="w-3.5 h-3.5 text-amber-700" />
          <span>Diagnostic Dermatology Lab</span>
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-medium text-stone-900 leading-tight">
          Personalized Beauty Prescription
        </h1>
        <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
          Our intelligent shade algorithm pairs your skin tone, undertone, and lipid profile with zero-flaking clean formulations.
        </p>
      </div>

      {/* Step Indicator */}
      <div className="flex items-center justify-center gap-2 max-w-md mx-auto">
        {[1, 2, 3, 4, 5].map(s => (
          <div key={s} className="flex-1 flex flex-col items-center gap-1">
            <div
              className={`h-1 w-full transition-colors ${
                step >= s ? 'bg-stone-900' : 'bg-stone-200'
              }`}
            />
            <span className="text-[10px] uppercase font-mono text-stone-400">
              {s === 5 ? 'Result' : `0${s}`}
            </span>
          </div>
        ))}
      </div>

      {/* Step 1: Skin Tone Spectrum */}
      {step === 1 && (
        <div className="bg-white border border-stone-200 p-6 sm:p-10 space-y-8 animate-fadeIn">
          <div>
            <span className="text-xs uppercase tracking-widest font-semibold text-stone-500">
              Question 1 of 4
            </span>
            <h2 className="text-2xl font-editorial font-semibold text-stone-900 mt-1">
              Select Your Skin Tone Baseline
            </h2>
            <p className="text-xs text-stone-500 mt-1">
              Choose the depth closest to your un-tanned facial complexion.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {toneOptions.map(item => {
              const isSelected = selectedSkinTone === item.tone;
              return (
                <button
                  key={item.tone}
                  onClick={() => {
                    sound.playClick();
                    setSelectedSkinTone(item.tone);
                  }}
                  className={`p-4 text-left border flex items-start gap-3 transition-all cursor-pointer ${
                    isSelected
                      ? 'border-stone-900 bg-[#FAF9F5] shadow-xs ring-1 ring-stone-900'
                      : 'border-stone-200 hover:border-stone-400'
                  }`}
                >
                  <span
                    className="w-7 h-7 rounded-full border border-stone-300 shrink-0 mt-0.5"
                    style={{ backgroundColor: item.sampleHex }}
                  />
                  <div>
                    <h3 className="text-xs font-semibold text-stone-900">{item.label}</h3>
                    <p className="text-[11px] text-stone-500 mt-0.5 leading-snug">{item.desc}</p>
                  </div>
                </button>
              );
            })}
          </div>

          <div className="flex justify-end pt-4 border-t border-stone-100">
            <button
              onClick={() => {
                sound.playClick();
                setStep(2);
              }}
              className="px-6 py-3 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors flex items-center gap-2 cursor-pointer"
            >
              <span>Next: Undertone Scan</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 2: Undertone Analysis */}
      {step === 2 && (
        <div className="bg-white border border-stone-200 p-6 sm:p-10 space-y-8 animate-fadeIn">
          <div>
            <span className="text-xs uppercase tracking-widest font-semibold text-stone-500">
              Question 2 of 4
            </span>
            <h2 className="text-2xl font-editorial font-semibold text-stone-900 mt-1">
              Identify Your Natural Undertone
            </h2>
            <p className="text-xs text-stone-500 mt-1">
              Check your inner wrist veins and the jewelry that brightens your face most.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {undertoneOptions.map(item => {
              const isSelected = selectedUndertone === item.undertone;
              return (
                <button
                  key={item.undertone}
                  onClick={() => {
                    sound.playClick();
                    setSelectedUndertone(item.undertone);
                  }}
                  className={`p-5 text-left border transition-all cursor-pointer ${
                    isSelected
                      ? 'border-stone-900 bg-[#FAF9F5] shadow-xs ring-1 ring-stone-900'
                      : 'border-stone-200 hover:border-stone-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs uppercase tracking-wider font-semibold text-stone-900">
                      {item.title}
                    </h3>
                    {isSelected && <Check className="w-4 h-4 text-stone-900" />}
                  </div>
                  <p className="text-xs text-stone-600 mt-2 leading-relaxed">{item.guide}</p>
                </button>
              );
            })}
          </div>

          <div className="flex justify-between pt-4 border-t border-stone-100">
            <button
              onClick={() => {
                sound.playClick();
                setStep(1);
              }}
              className="px-4 py-2.5 text-xs uppercase tracking-wider font-medium text-stone-600 hover:text-stone-900 cursor-pointer"
            >
              Back
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setStep(3);
              }}
              className="px-6 py-3 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors flex items-center gap-2 cursor-pointer"
            >
              <span>Next: Skin Type</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 3: Skin Type */}
      {step === 3 && (
        <div className="bg-white border border-stone-200 p-6 sm:p-10 space-y-8 animate-fadeIn">
          <div>
            <span className="text-xs uppercase tracking-widest font-semibold text-stone-500">
              Question 3 of 4
            </span>
            <h2 className="text-2xl font-editorial font-semibold text-stone-900 mt-1">
              What Is Your Skin Barrier Type?
            </h2>
            <p className="text-xs text-stone-500 mt-1">
              Ensures we pair appropriate plant squalanes or oil-regulating niacinamides.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
            {skinTypeOptions.map(item => {
              const isSelected = selectedSkinType === item.type;
              return (
                <button
                  key={item.type}
                  onClick={() => {
                    sound.playClick();
                    setSelectedSkinType(item.type);
                  }}
                  className={`p-4 text-left border transition-all cursor-pointer ${
                    isSelected
                      ? 'border-stone-900 bg-[#FAF9F5] shadow-xs ring-1 ring-stone-900'
                      : 'border-stone-200 hover:border-stone-400'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-semibold text-stone-900">{item.title}</h3>
                    {isSelected && <Check className="w-3.5 h-3.5 text-stone-900" />}
                  </div>
                  <p className="text-[11px] text-stone-500 mt-1.5 leading-snug">{item.desc}</p>
                </button>
              );
            })}
          </div>

          <div className="flex justify-between pt-4 border-t border-stone-100">
            <button
              onClick={() => {
                sound.playClick();
                setStep(2);
              }}
              className="px-4 py-2.5 text-xs uppercase tracking-wider font-medium text-stone-600 hover:text-stone-900 cursor-pointer"
            >
              Back
            </button>
            <button
              onClick={() => {
                sound.playClick();
                setStep(4);
              }}
              className="px-6 py-3 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors flex items-center gap-2 cursor-pointer"
            >
              <span>Next: Primary Concerns</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Step 4: Concerns */}
      {step === 4 && (
        <div className="bg-white border border-stone-200 p-6 sm:p-10 space-y-8 animate-fadeIn">
          <div>
            <span className="text-xs uppercase tracking-widest font-semibold text-stone-500">
              Question 4 of 4
            </span>
            <h2 className="text-2xl font-editorial font-semibold text-stone-900 mt-1">
              Select Your Target Beauty Goals
            </h2>
            <p className="text-xs text-stone-500 mt-1">
              Choose any concerns you want our bio-active botanicals to target simultaneously.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {concernOptions.map(concern => {
              const isSelected = selectedConcerns.includes(concern);
              return (
                <button
                  key={concern}
                  type="button"
                  onClick={() => handleToggleConcern(concern)}
                  className={`p-4 text-left border flex items-center justify-between transition-all cursor-pointer ${
                    isSelected
                      ? 'border-stone-900 bg-[#FAF9F5] shadow-xs'
                      : 'border-stone-200 hover:border-stone-400'
                  }`}
                >
                  <span className="text-xs font-medium text-stone-900">{concern}</span>
                  <div
                    className={`w-4 h-4 border flex items-center justify-center ${
                      isSelected ? 'bg-stone-900 border-stone-900 text-white' : 'border-stone-300'
                    }`}
                  >
                    {isSelected && <Check className="w-3 h-3" />}
                  </div>
                </button>
              );
            })}
          </div>

          <div className="flex justify-between pt-4 border-t border-stone-100">
            <button
              onClick={() => {
                sound.playClick();
                setStep(3);
              }}
              className="px-4 py-2.5 text-xs uppercase tracking-wider font-medium text-stone-600 hover:text-stone-900 cursor-pointer"
            >
              Back
            </button>
            <button
              onClick={handleGeneratePrescription}
              className="px-6 py-3 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors flex items-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>Generate My Beauty Prescription</span>
            </button>
          </div>
        </div>
      )}

      {/* Step 5: Prescription & Results */}
      {step === 5 && (
        <div className="space-y-8 animate-fadeIn">
          {/* Diagnostic Summary Header */}
          <div className="bg-[#FAF7F0] border border-stone-300 p-6 sm:p-8 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div className="space-y-1">
              <span className="text-[11px] uppercase tracking-widest font-semibold text-stone-500">
                Diagnostic Analysis Verified
              </span>
              <h2 className="text-2xl font-editorial font-medium text-stone-900">
                Your Bespoke Atelier Prescription
              </h2>
              <div className="flex flex-wrap items-center gap-2 text-xs text-stone-600 pt-1">
                <span>Tone: <strong className="text-stone-900">{selectedSkinTone}</strong></span>
                <span aria-hidden="true">·</span>
                <span>Undertone: <strong className="text-stone-900">{selectedUndertone}</strong></span>
                <span aria-hidden="true">·</span>
                <span>Type: <strong className="text-stone-900">{selectedSkinType}</strong></span>
              </div>
            </div>

            <button
              onClick={() => {
                sound.playClick();
                setStep(1);
              }}
              className="text-xs uppercase tracking-wider font-semibold text-stone-800 hover:text-stone-950 underline self-start md:self-center cursor-pointer"
            >
              Retake Diagnostic
            </button>
          </div>

          {/* Matched Formula Trio */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Foundation Match */}
            <div className="bg-white border border-stone-200 p-5 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-center text-xs text-stone-500 mb-2">
                  <span className="uppercase">Match 01 · Complexion</span>
                  <span className="font-mono text-emerald-800 font-semibold">99% Match</span>
                </div>
                <h3 className="font-editorial text-base font-semibold text-stone-900">
                  {foundationProduct.name}
                </h3>
                <p className="text-xs text-stone-500 mt-1">{foundationProduct.subtitle}</p>

                <div className="mt-4 p-3 bg-stone-50 border border-stone-200 flex items-center gap-3">
                  <span
                    className="w-6 h-6 rounded-full border border-stone-300 shrink-0"
                    style={{ backgroundColor: matchedFoundationShade.hex }}
                  />
                  <div>
                    <p className="text-xs font-semibold text-stone-900">{matchedFoundationShade.name}</p>
                    <p className="text-[10px] text-stone-500">Formulated for {selectedSkinTone} skin</p>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between">
                <span className="font-mono tabular-nums font-semibold text-stone-900">₹{foundationProduct.price.toLocaleString('en-IN')}</span>
                <button
                  onClick={() => {
                    sound.playChime();
                    addToCart(foundationProduct, matchedFoundationShade);
                  }}
                  className="px-3 py-1.5 bg-stone-900 text-white text-xs uppercase tracking-wider font-medium hover:bg-stone-800 cursor-pointer"
                >
                  Add Shade
                </button>
              </div>
            </div>

            {/* Lip Match */}
            <div className="bg-white border border-stone-200 p-5 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-center text-xs text-stone-500 mb-2">
                  <span className="uppercase">Match 02 · Lip Velvet</span>
                  <span className="font-mono text-emerald-800 font-semibold">97% Match</span>
                </div>
                <h3 className="font-editorial text-base font-semibold text-stone-900">
                  {lipProduct.name}
                </h3>
                <p className="text-xs text-stone-500 mt-1">{lipProduct.subtitle}</p>

                <div className="mt-4 p-3 bg-stone-50 border border-stone-200 flex items-center gap-3">
                  <span
                    className="w-6 h-6 rounded-full border border-stone-300 shrink-0"
                    style={{ backgroundColor: matchedLipShade.hex }}
                  />
                  <div>
                    <p className="text-xs font-semibold text-stone-900">{matchedLipShade.name}</p>
                    <p className="text-[10px] text-stone-500">Complements {selectedUndertone} undertone</p>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between">
                <span className="font-mono tabular-nums font-semibold text-stone-900">₹{lipProduct.price.toLocaleString('en-IN')}</span>
                <button
                  onClick={() => {
                    sound.playChime();
                    addToCart(lipProduct, matchedLipShade);
                  }}
                  className="px-3 py-1.5 bg-stone-900 text-white text-xs uppercase tracking-wider font-medium hover:bg-stone-800 cursor-pointer"
                >
                  Add Shade
                </button>
              </div>
            </div>

            {/* Blush Match */}
            <div className="bg-white border border-stone-200 p-5 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-center text-xs text-stone-500 mb-2">
                  <span className="uppercase">Match 03 · Cheek Flush</span>
                  <span className="font-mono text-emerald-800 font-semibold">98% Match</span>
                </div>
                <h3 className="font-editorial text-base font-semibold text-stone-900">
                  {blushProduct.name}
                </h3>
                <p className="text-xs text-stone-500 mt-1">{blushProduct.subtitle}</p>

                <div className="mt-4 p-3 bg-stone-50 border border-stone-200 flex items-center gap-3">
                  <span
                    className="w-6 h-6 rounded-full border border-stone-300 shrink-0"
                    style={{ backgroundColor: matchedBlushShade.hex }}
                  />
                  <div>
                    <p className="text-xs font-semibold text-stone-900">{matchedBlushShade.name}</p>
                    <p className="text-[10px] text-stone-500">Dewy moisture balm</p>
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between">
                <span className="font-mono tabular-nums font-semibold text-stone-900">₹{blushProduct.price.toLocaleString('en-IN')}</span>
                <button
                  onClick={() => {
                    sound.playChime();
                    addToCart(blushProduct, matchedBlushShade);
                  }}
                  className="px-3 py-1.5 bg-stone-900 text-white text-xs uppercase tracking-wider font-medium hover:bg-stone-800 cursor-pointer"
                >
                  Add Shade
                </button>
              </div>
            </div>
          </div>

          {/* Bundle Call to Action */}
          <div className="bg-stone-900 text-white p-6 sm:p-8 flex flex-col sm:flex-row items-center justify-between gap-6">
            <div>
              <span className="text-[10px] uppercase tracking-widest font-semibold text-amber-300">
                Prescription Bundle Discount
              </span>
              <h3 className="text-xl font-editorial font-medium mt-1">
                Add Complete 3-Piece Regimen to Bag
              </h3>
              <p className="text-xs text-stone-300 mt-1">
                Includes Foundation, Liquid Velvet Lip, and Cream Blush in your exact diagnosed shades.
              </p>
            </div>

            <div className="flex items-center gap-4">
              <div className="text-right">
                <span className="line-through text-stone-400 text-xs tabular-nums font-mono">₹6,350</span>
                <p className="text-lg font-mono font-semibold tabular-nums text-white">₹5,399</p>
              </div>

              <button
                onClick={handleAddFullPrescription}
                className="px-6 py-3.5 bg-white text-stone-900 text-xs uppercase tracking-widest font-semibold hover:bg-stone-100 transition-colors whitespace-nowrap cursor-pointer flex items-center gap-2"
              >
                <ShoppingBag className="w-4 h-4" />
                <span>Add Prescribed Trio</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Interactive AI Dermatological & Ingredient Intelligence Studio */}
      <section className="bg-white border border-stone-200 p-6 sm:p-8 space-y-6">
        <div className="flex items-center justify-between border-b border-stone-100 pb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-stone-100 text-stone-900 border border-stone-200">
              <Bot className="w-4 h-4 text-stone-800" />
            </div>
            <div>
              <h3 className="text-sm uppercase tracking-wider font-semibold text-stone-900">
                Aura Clinical Formula Advisor
              </h3>
              <p className="text-xs text-stone-500">
                Ask specific biochemical or application questions for your skin barrier
              </p>
            </div>
          </div>
          <span className="text-[10px] uppercase font-mono bg-[#FAF7F0] px-2 py-1 border border-stone-300 text-stone-700">
            Dermatologically Calibrated
          </span>
        </div>

        {/* Quick prompt prompts */}
        <div className="flex flex-wrap gap-2 text-xs">
          <span className="text-stone-400 text-[11px] self-center">Suggested queries:</span>
          {[
            'Will the velvet lipstick settle into lip lines?',
            'Is the 4% niacinamide foundation safe for rosacea?',
            'What makes squalane better than synthetic dimethicone?'
          ].map((prompt, i) => (
            <button
              key={i}
              onClick={() => {
                sound.playClick();
                setAiQuestion(prompt);
              }}
              className="px-2.5 py-1 bg-stone-50 border border-stone-200 text-stone-700 hover:border-stone-900 hover:bg-white text-[11px] transition-colors cursor-pointer"
            >
              {prompt}
            </button>
          ))}
        </div>

        {/* Question Input */}
        <form onSubmit={handleAskAiConsultant} className="flex gap-2">
          <input
            type="text"
            value={aiQuestion}
            onChange={e => setAiQuestion(e.target.value)}
            placeholder="Type any makeup, shade match, or ingredient concern..."
            className="flex-1 px-4 py-2.5 text-xs border border-stone-300 bg-[#FAF9F5] focus:outline-none focus:border-stone-900"
          />
          <button
            type="submit"
            disabled={isAiConsulting}
            className="px-5 py-2.5 bg-stone-900 text-white text-xs uppercase tracking-wider font-semibold hover:bg-stone-800 transition-colors flex items-center gap-1.5 cursor-pointer disabled:opacity-50"
          >
            {isAiConsulting ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            <span>Consult</span>
          </button>
        </form>

        {/* AI Answer Card */}
        {aiResponse && (
          <div className="p-5 bg-[#FAF7F0] border border-stone-300 space-y-3 animate-fadeIn">
            <div className="flex items-center justify-between text-xs text-stone-500 border-b border-stone-200/80 pb-2">
              <span className="font-semibold text-stone-800 font-mono">Q: {aiResponse.query}</span>
              <span className="text-[10px] text-emerald-800 font-medium">100% Non-Comedogenic Guidance</span>
            </div>
            <p className="text-xs text-stone-700 leading-relaxed">
              {aiResponse.answer}
            </p>
            <div className="pt-2 flex items-center justify-between">
              <span className="text-[11px] text-stone-500">
                Key botanical involved: <strong className="text-stone-900">{aiResponse.recommendedIngredient}</strong>
              </span>
              <button
                type="button"
                onClick={() => setSelectedIngredientForModal(aiResponse.recommendedIngredient)}
                className="text-xs font-semibold text-stone-900 underline hover:text-stone-700 cursor-pointer"
              >
                Inspect Clinical Dossier →
              </button>
            </div>
          </div>
        )}
      </section>
    </div>
  );
};
