import React, { useState, useMemo } from 'react';
import { Search, Filter, X, SlidersHorizontal, Sparkles, Star, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PRODUCTS, ALL_KEY_INGREDIENTS } from '../data/products';
import { Product, SkinToneCategory, Shade } from '../types';

export const ShopPage: React.FC = () => {
  const { addToCart, setQuickViewProduct, setCurrentPage, setSelectedIngredientForModal } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedIngredient, setSelectedIngredient] = useState<string>('All');
  const [selectedSkinTone, setSelectedSkinTone] = useState<SkinToneCategory | 'All'>('All');
  const [selectedCertification, setSelectedCertification] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'featured' | 'price-asc' | 'price-desc' | 'rating'>('featured');
  const [activeShades, setActiveShades] = useState<Record<string, Shade>>({});

  const categories = ['All', 'Lips', 'Complexion', 'Cheeks', 'Eyes', 'Hybrid Care'];
  const skinTones: (SkinToneCategory | 'All')[] = ['All', 'Fair', 'Light', 'Medium', 'Tan', 'Deep', 'Rich'];
  const certifications = ['All', 'Vegan', 'Cruelty-Free', 'Paraben-Free', 'Fragrance-Free', 'Silicone-Free'];

  // Filter products
  const filteredProducts = useMemo(() => {
    return PRODUCTS.filter(prod => {
      // Search by name, subtitle, or ingredients
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchesName = prod.name.toLowerCase().includes(query);
        const matchesSub = prod.subtitle.toLowerCase().includes(query);
        const matchesIng = prod.ingredients.some(ing => ing.name.toLowerCase().includes(query) || ing.benefit.toLowerCase().includes(query));
        const matchesCat = prod.category.toLowerCase().includes(query);
        if (!matchesName && !matchesSub && !matchesIng && !matchesCat) {
          return false;
        }
      }

      // Category filter
      if (selectedCategory !== 'All' && prod.category !== selectedCategory) {
        return false;
      }

      // Specific key ingredient filter
      if (selectedIngredient !== 'All') {
        const hasIngredient = prod.ingredients.some(ing =>
          ing.name.toLowerCase().includes(selectedIngredient.toLowerCase())
        );
        if (!hasIngredient) return false;
      }

      // Skin tone match
      if (selectedSkinTone !== 'All') {
        if (!prod.suitableSkinTones.includes(selectedSkinTone)) {
          return false;
        }
      }

      // Clean certification
      if (selectedCertification !== 'All') {
        if (!prod.certifications.includes(selectedCertification as any)) {
          return false;
        }
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0; // featured default
    });
  }, [searchQuery, selectedCategory, selectedIngredient, selectedSkinTone, selectedCertification, sortBy]);

  const handleSelectShade = (productId: string, shade: Shade) => {
    setActiveShades(prev => ({ ...prev, [productId]: shade }));
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedIngredient('All');
    setSelectedSkinTone('All');
    setSelectedCertification('All');
    setSortBy('featured');
  };

  const hasActiveFilters =
    searchQuery !== '' ||
    selectedCategory !== 'All' ||
    selectedIngredient !== 'All' ||
    selectedSkinTone !== 'All' ||
    selectedCertification !== 'All';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-10">
      {/* Header */}
      <div className="space-y-3 border-b border-stone-200 pb-8">
        <div className="flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-stone-500">
          <span>The Formulations</span>
          <span aria-hidden="true">·</span>
          <span>Clean Botanical Chemistry</span>
        </div>
        <h1 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-medium text-stone-900 leading-tight">
          Pure Pigments, Zero Compromise.
        </h1>
        <p className="text-sm text-stone-600 max-w-2xl leading-relaxed">
          Filter by your exact skin undertone, or browse by targeted bio-active ingredients like squalane, plant peptides, and micro-hyaluronic spheres.
        </p>
      </div>

      {/* Search and Filters Control Center */}
      <div className="bg-white border border-stone-200 p-6 space-y-6">
        {/* Top Search Bar */}
        <div className="relative">
          <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3.5" />
          <input
            type="text"
            placeholder="Search by product name, active ingredient (e.g. Squalane, Niacinamide), or skin goal..."
            value={searchQuery}
            onChange={e => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm border border-stone-300 focus:outline-none focus:border-stone-900 bg-[#FAF9F5]"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-3 text-stone-400 hover:text-stone-700"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Filter Rows */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 pt-2 border-t border-stone-100">
          {/* Category Dropdown */}
          <div className="space-y-1.5">
            <label className="text-[11px] uppercase tracking-wider font-semibold text-stone-500 block">
              Formulation Category
            </label>
            <select
              value={selectedCategory}
              onChange={e => setSelectedCategory(e.target.value)}
              className="w-full text-xs py-2 px-2.5 border border-stone-300 bg-white focus:outline-none focus:border-stone-900"
            >
              {categories.map(cat => (
                <option key={cat} value={cat}>
                  {cat === 'All' ? 'All Categories' : cat}
                </option>
              ))}
            </select>
          </div>

          {/* Key Bio-Active Ingredient Filter (Crucial user request!) */}
          <div className="space-y-1.5">
            <label className="text-[11px] uppercase tracking-wider font-semibold text-stone-500 block">
              Filter by Active Ingredient
            </label>
            <select
              value={selectedIngredient}
              onChange={e => setSelectedIngredient(e.target.value)}
              className="w-full text-xs py-2 px-2.5 border border-stone-300 bg-white focus:outline-none focus:border-stone-900"
            >
              <option value="All">All Botanical Actives</option>
              {ALL_KEY_INGREDIENTS.map(ing => (
                <option key={ing} value={ing}>
                  {ing}
                </option>
              ))}
            </select>
          </div>

          {/* Skin Tone Filter */}
          <div className="space-y-1.5">
            <label className="text-[11px] uppercase tracking-wider font-semibold text-stone-500 block">
              Match Skin Tone
            </label>
            <select
              value={selectedSkinTone}
              onChange={e => setSelectedSkinTone(e.target.value as any)}
              className="w-full text-xs py-2 px-2.5 border border-stone-300 bg-white focus:outline-none focus:border-stone-900"
            >
              {skinTones.map(tone => (
                <option key={tone} value={tone}>
                  {tone === 'All' ? 'All Skin Tones' : `${tone} Complexion`}
                </option>
              ))}
            </select>
          </div>

          {/* Sorting */}
          <div className="space-y-1.5">
            <label className="text-[11px] uppercase tracking-wider font-semibold text-stone-500 block">
              Sort By
            </label>
            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="w-full text-xs py-2 px-2.5 border border-stone-300 bg-white focus:outline-none focus:border-stone-900"
            >
              <option value="featured">Featured Atelier Order</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
            </select>
          </div>
        </div>

        {/* Clean Standard Tags (Interactive Segmented buttons) */}
        <div className="pt-3 border-t border-stone-100 flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-1.5">
            <span className="text-[11px] uppercase tracking-wider font-semibold text-stone-500 mr-2">
              Clean Standard:
            </span>
            {certifications.map(cert => {
              const active = selectedCertification === cert;
              return (
                <button
                  key={cert}
                  onClick={() => setSelectedCertification(cert)}
                  className={`px-2.5 py-1 text-xs transition-colors cursor-pointer border ${
                    active
                      ? 'bg-stone-900 text-white border-stone-900'
                      : 'bg-white text-stone-600 border-stone-200 hover:border-stone-400'
                  }`}
                >
                  {cert}
                </button>
              );
            })}
          </div>

          {hasActiveFilters && (
            <button
              onClick={handleResetFilters}
              className="text-xs text-stone-500 hover:text-stone-900 underline cursor-pointer"
            >
              Clear all filters
            </button>
          )}
        </div>
      </div>

      {/* Catalog Results Header */}
      <div className="flex items-center justify-between text-xs text-stone-500">
        <span>
          Showing <strong className="text-stone-900 tabular-nums">{filteredProducts.length}</strong> clean formulations
        </span>
        <span className="font-mono">Batch 04 · Ready for Dispatch</span>
      </div>

      {/* Products Grid */}
      {filteredProducts.length === 0 ? (
        <div className="text-center py-20 bg-white border border-stone-200 p-8 space-y-4">
          <p className="text-stone-500 text-sm">No formulations match your specific ingredient or tone filter combination.</p>
          <button
            onClick={handleResetFilters}
            className="px-6 py-2.5 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map(product => {
            const currentShade = activeShades[product.id] || product.shades[0];

            return (
              <div
                key={product.id}
                className="group bg-white border border-stone-200 p-6 flex flex-col justify-between transition-all duration-300 hover:shadow-md"
              >
                <div>
                  {/* Image & Quick View trigger */}
                  <div
                    onClick={() => setQuickViewProduct(product)}
                    className="aspect-4/3 bg-[#F9F9F8] overflow-hidden border border-stone-100 relative cursor-pointer"
                  >
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      referrerPolicy="no-referrer"
                    />
                    <div className="absolute top-3 left-3 flex flex-col gap-1">
                      {product.isBestSeller && (
                        <span className="text-[10px] uppercase tracking-widest font-semibold bg-white/95 px-2 py-0.5 border border-stone-200 text-stone-800">
                          Best Seller
                        </span>
                      )}
                      {product.isNewArrival && (
                        <span className="text-[10px] uppercase tracking-widest font-semibold bg-stone-900 px-2 py-0.5 text-white">
                          New Formula
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Metadata */}
                  <div className="mt-5 space-y-2">
                    <div className="flex items-center justify-between text-xs text-stone-500">
                      <span className="uppercase tracking-wider">{product.category}</span>
                      <div className="flex items-center gap-1 text-stone-700">
                        <Star className="w-3 h-3 fill-stone-700 stroke-stone-700" />
                        <span className="font-mono tabular-nums">{product.rating}</span>
                      </div>
                    </div>

                    <h3
                      onClick={() => setQuickViewProduct(product)}
                      className="font-editorial text-lg font-semibold text-stone-900 leading-snug cursor-pointer hover:text-stone-700 transition-colors"
                    >
                      {product.name}
                    </h3>

                    <p className="text-xs text-stone-500 line-clamp-2 leading-relaxed">
                      {product.subtitle}
                    </p>

                    <p className="font-mono text-stone-900 font-semibold text-base tabular-nums pt-1">
                      ₹{product.price.toLocaleString('en-IN')}
                    </p>
                  </div>

                  {/* Shade Swatch Selector */}
                  <div className="mt-4 pt-3 border-t border-stone-100">
                    <div className="flex items-center justify-between text-xs mb-2">
                      <span className="text-stone-500">Shade:</span>
                      <span className="text-stone-900 font-medium truncate max-w-[160px]">
                        {currentShade.name}
                      </span>
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {product.shades.map(sh => {
                        const isSelected = currentShade.id === sh.id;
                        return (
                          <button
                            key={sh.id}
                            onClick={() => handleSelectShade(product.id, sh)}
                            className={`w-5 h-5 rounded-full border transition-all cursor-pointer ${
                              isSelected ? 'ring-2 ring-stone-900 ring-offset-1 scale-110' : 'border-stone-300 hover:scale-105'
                            }`}
                            style={{ backgroundColor: sh.hex }}
                            title={`${sh.name} - ${sh.finish}`}
                          />
                        );
                      })}
                    </div>
                  </div>

                  {/* Key Actives Chips */}
                  <div className="mt-4 pt-3 border-t border-stone-100 text-[11px] text-stone-500">
                    <div className="flex items-center justify-between mb-1">
                      <span className="font-semibold text-stone-700">Bio-Actives:</span>
                      <span className="text-[10px] text-stone-400">Click for dossier</span>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {product.ingredients.filter(i => i.isKeyActive).map((i, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => setSelectedIngredientForModal(i.name)}
                          className="hover:text-stone-900 underline underline-offset-2 transition-colors cursor-pointer text-left"
                        >
                          {i.name}
                          {idx < product.ingredients.filter(i => i.isKeyActive).length - 1 ? ' · ' : ''}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Card CTA Actions */}
                <div className="mt-6 pt-4 border-t border-stone-100 space-y-2">
                  <button
                    onClick={() => addToCart(product, currentShade)}
                    className="w-full py-2.5 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors cursor-pointer"
                  >
                    Add To Bag · ₹{product.price.toLocaleString('en-IN')}
                  </button>

                  {product.tryOnType && (
                    <button
                      onClick={() => setCurrentPage('tryon')}
                      className="w-full py-2 bg-[#FAF7F0] border border-stone-300 text-stone-800 text-[11px] uppercase tracking-wider font-medium hover:bg-stone-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Sparkles className="w-3 h-3 text-stone-700" />
                      <span>Test In Virtual Studio</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
