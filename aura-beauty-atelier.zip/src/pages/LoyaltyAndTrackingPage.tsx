import React, { useState } from 'react';
import {
  Award,
  Package,
  Gift,
  Truck,
  CheckCircle2,
  Clock,
  Sparkles,
  ArrowRight,
  ChevronRight,
  Copy,
  Check,
  RefreshCw,
  Bell,
  MapPin,
  Calendar,
  AlertCircle,
  Thermometer,
  ShieldAlert,
  Navigation
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { LOYALTY_TIERS, LOYALTY_REWARDS } from '../data/products';
import { Order } from '../types';
import { sound } from '../utils/audio';

export const LoyaltyAndTrackingPage: React.FC = () => {
  const {
    loyaltyPoints,
    addLoyaltyPoints,
    dailyStreak,
    hasCheckedInToday,
    claimDailyCheckIn,
    redeemReward,
    redeemedRewards,
    orders,
    activeTrackingOrder,
    setActiveTrackingOrder,
    advanceOrderSimulation,
    triggerPushNotification,
    setCurrentPage
  } = useApp();

  const [activeTab, setActiveTab] = useState<'loyalty' | 'tracking'>('tracking');
  const [copiedCode, setCopiedCode] = useState<string | null>(null);

  // Delivery preferences
  const [deliveryNote, setDeliveryNote] = useState<string>('Leave with building concierge');
  const [noteSaved, setNoteSaved] = useState<boolean>(false);

  // Mystery Box State
  const [mysteryOpened, setMysteryOpened] = useState<boolean>(false);
  const [mysteryGift, setMysteryGift] = useState<{ title: string; desc: string; code: string } | null>(null);

  // Current tier calculation
  const currentTier =
    [...LOYALTY_TIERS].reverse().find(t => loyaltyPoints >= t.minPoints) || LOYALTY_TIERS[0];
  const nextTierIndex = LOYALTY_TIERS.findIndex(t => t.name === currentTier.name) + 1;
  const nextTier = nextTierIndex < LOYALTY_TIERS.length ? LOYALTY_TIERS[nextTierIndex] : null;

  const pointsToNext = nextTier ? nextTier.minPoints - loyaltyPoints : 0;
  const progressToNext = nextTier
    ? Math.min(
        100,
        Math.max(
          0,
          ((loyaltyPoints - currentTier.minPoints) /
            (nextTier.minPoints - currentTier.minPoints)) *
            100
        )
      )
    : 100;

  const handleCopyCode = (code: string) => {
    sound.playClick();
    navigator.clipboard?.writeText(code);
    setCopiedCode(code);
    setTimeout(() => setCopiedCode(null), 2500);
  };

  const handleOpenMysteryVault = () => {
    if (mysteryOpened) return;
    sound.playChime();
    setMysteryOpened(true);
    addLoyaltyPoints(50);
    setMysteryGift({
      title: '+50 Glow Points & Deluxe Sample Pass',
      desc: 'Free 5ml Lucent Crystalline Glaze on your next order.',
      code: 'MYSTERYGLAZE50'
    });
  };

  const handleSaveDeliveryNote = () => {
    sound.playClick();
    setNoteSaved(true);
    setTimeout(() => setNoteSaved(false), 2500);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-16 space-y-12">
      {/* Page Title & Main Segmented Navigation */}
      <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-stone-200 pb-6 gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-stone-500">
            <span>Customer Atelier Hub</span>
            <span aria-hidden="true">·</span>
            <span>Real-Time Services</span>
          </div>
          <h1 className="text-3xl sm:text-4xl lg:text-5xl font-editorial font-medium text-stone-900 leading-tight mt-1">
            Glow Rewards & Live Tracking
          </h1>
        </div>

        {/* Tab Switcher */}
        <div className="flex p-1 bg-stone-200 border border-stone-300">
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('tracking');
            }}
            className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'tracking'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'text-stone-700 hover:text-stone-900'
            }`}
          >
            <Truck className="w-3.5 h-3.5" />
            <span>Live Order Tracking</span>
          </button>
          <button
            onClick={() => {
              sound.playClick();
              setActiveTab('loyalty');
            }}
            className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold transition-colors flex items-center gap-2 cursor-pointer ${
              activeTab === 'loyalty'
                ? 'bg-stone-900 text-white shadow-xs'
                : 'text-stone-700 hover:text-stone-900'
            }`}
          >
            <Gift className="w-3.5 h-3.5" />
            <span>Aura Glow Club ({loyaltyPoints} pts)</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* TAB 1: REAL-TIME LIVE ORDER TRACKING */}
      {/* ========================================================================= */}
      {activeTab === 'tracking' && (
        <div className="space-y-10 animate-fadeIn">
          {orders.length === 0 ? (
            <div className="text-center py-16 bg-white border border-stone-200 p-8 space-y-4">
              <Package className="w-8 h-8 text-stone-400 mx-auto" />
              <p className="text-sm text-stone-600">You do not have any active cosmetic orders placed yet.</p>
              <button
                onClick={() => setCurrentPage('shop')}
                className="px-6 py-2.5 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800"
              >
                Browse The Atelier Catalog
              </button>
            </div>
          ) : (
            <>
              {/* Order selector bar if multiple orders exist */}
              {orders.length > 1 && (
                <div className="flex items-center gap-3 overflow-x-auto pb-2">
                  <span className="text-xs uppercase tracking-wider font-semibold text-stone-500 whitespace-nowrap">
                    Select Order:
                  </span>
                  {orders.map(ord => (
                    <button
                      key={ord.id}
                      onClick={() => {
                        sound.playClick();
                        setActiveTrackingOrder(ord);
                      }}
                      className={`px-3 py-1.5 text-xs font-mono border transition-colors whitespace-nowrap cursor-pointer ${
                        activeTrackingOrder?.id === ord.id
                          ? 'bg-stone-900 text-white border-stone-900'
                          : 'bg-white text-stone-700 border-stone-300 hover:border-stone-500'
                      }`}
                    >
                      {ord.orderNumber} ({ord.steps[ord.currentStepIndex]?.status})
                    </button>
                  ))}
                </div>
              )}

              {activeTrackingOrder && (
                <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
                  {/* Left Column: Live Progress Stepper & Timeline */}
                  <div className="lg:col-span-7 bg-white border border-stone-200 p-6 sm:p-8 space-y-8">
                    {/* Order Meta Header */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-6 border-b border-stone-200 gap-4">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs uppercase tracking-widest font-mono text-stone-500">
                            Tracking: {activeTrackingOrder.trackingNumber}
                          </span>
                          <span className="w-2 h-2 rounded-full bg-emerald-700 animate-pulse" />
                        </div>
                        <h2 className="text-2xl font-editorial font-semibold text-stone-900 mt-1">
                          {activeTrackingOrder.orderNumber}
                        </h2>
                        <p className="text-xs text-stone-500 mt-0.5">
                          Carrier: {activeTrackingOrder.carrier} · ETA: {activeTrackingOrder.estimatedDelivery}
                        </p>
                      </div>

                      {/* Interactive Simulation Trigger */}
                      <button
                        onClick={() => {
                          sound.playChime();
                          advanceOrderSimulation(activeTrackingOrder.id);
                        }}
                        className="px-4 py-2 bg-[#FAF7F0] border border-stone-300 text-stone-800 text-xs uppercase tracking-wider font-semibold hover:bg-stone-200 transition-colors flex items-center gap-2 cursor-pointer self-start sm:self-center"
                        title="Simulate courier moving to the next physical milestone"
                      >
                        <RefreshCw className="w-3.5 h-3.5 text-stone-700" />
                        <span>Simulate Next Step</span>
                      </button>
                    </div>

                    {/* Step Timeline */}
                    <div className="space-y-6">
                      <h3 className="text-xs uppercase tracking-widest font-semibold text-stone-900">
                        Live Dispatch & Formulation Timeline
                      </h3>

                      <div className="relative pl-6 sm:pl-8 space-y-8 before:absolute before:left-3 sm:before:left-4 before:top-2 before:bottom-2 before:w-0.5 before:bg-stone-200">
                        {activeTrackingOrder.steps.map((st, idx) => {
                          const isCurrent = idx === activeTrackingOrder.currentStepIndex;
                          const isPast = idx < activeTrackingOrder.currentStepIndex;

                          return (
                            <div key={idx} className="relative group">
                              {/* Step dot */}
                              <div
                                className={`absolute -left-6 sm:-left-8 top-0.5 w-6 h-6 rounded-full border-2 flex items-center justify-center transition-colors ${
                                  isCurrent
                                    ? 'bg-stone-900 border-stone-900 text-white shadow-md'
                                    : isPast
                                    ? 'bg-emerald-600 border-emerald-600 text-white'
                                    : 'bg-white border-stone-300 text-stone-300'
                                }`}
                              >
                                {isPast ? (
                                  <Check className="w-3 h-3 stroke-[3]" />
                                ) : (
                                  <span className="text-[10px] font-mono">{idx + 1}</span>
                                )}
                              </div>

                              {/* Step details */}
                              <div>
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                                  <h4
                                    className={`text-sm font-semibold ${
                                      isCurrent
                                        ? 'text-stone-950 font-bold'
                                        : isPast
                                        ? 'text-stone-800'
                                        : 'text-stone-400'
                                    }`}
                                  >
                                    {st.status}
                                  </h4>
                                  <span className="text-[11px] text-stone-400 font-mono">
                                    {st.timestamp}
                                  </span>
                                </div>

                                <div className="flex items-center gap-1.5 text-xs text-stone-500 mt-1">
                                  <MapPin className="w-3 h-3 shrink-0 text-stone-400" />
                                  <span>{st.location}</span>
                                </div>

                                {st.note && (
                                  <p
                                    className={`text-xs mt-1.5 leading-relaxed p-2.5 border ${
                                      isCurrent
                                        ? 'bg-[#FAF7F0] border-stone-300 text-stone-800'
                                        : 'bg-stone-50 border-stone-200 text-stone-600'
                                    }`}
                                  >
                                    {st.note}
                                  </p>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </div>

                    {/* Delivery Instructions customizer */}
                    <div className="pt-6 border-t border-stone-200 space-y-3">
                      <h4 className="text-xs uppercase tracking-wider font-semibold text-stone-800">
                        Delivery Gate & Courier Directives:
                      </h4>
                      <div className="flex gap-2">
                        <select
                          value={deliveryNote}
                          onChange={e => setDeliveryNote(e.target.value)}
                          className="flex-1 text-xs border border-stone-300 bg-[#FAF9F5] p-2 focus:outline-none focus:border-stone-900"
                        >
                          <option value="Leave with building concierge">Leave with building concierge</option>
                          <option value="Contactless doorstep delivery">Contactless doorstep delivery</option>
                          <option value="Require recipient physical signature">Require recipient physical signature</option>
                          <option value="Ring intercom code #410">Ring intercom code #410</option>
                        </select>
                        <button
                          onClick={handleSaveDeliveryNote}
                          className="px-4 py-2 bg-stone-900 text-white text-xs uppercase tracking-wider font-semibold hover:bg-stone-800 cursor-pointer"
                        >
                          {noteSaved ? 'Saved!' : 'Update'}
                        </button>
                      </div>
                    </div>
                  </div>

                  {/* Right Column: Animated Vector Route Radar & Atmospheric Telemetry */}
                  <div className="lg:col-span-5 space-y-6">
                    {/* Radar Screen Graphic */}
                    <div className="bg-[#1C1917] text-white p-6 border border-stone-800 space-y-4">
                      <div className="flex items-center justify-between text-xs text-stone-400 border-b border-stone-800 pb-3">
                        <div className="flex items-center gap-1.5">
                          <Navigation className="w-3.5 h-3.5 text-amber-400 animate-spin" />
                          <span className="uppercase tracking-wider font-mono">Live Route Vector</span>
                        </div>
                        <span className="font-mono text-emerald-400 tabular-nums">DHL COURIER GPS</span>
                      </div>

                      {/* Vector Map Canvas graphic */}
                      <div className="relative aspect-4/3 bg-stone-900 border border-stone-800 overflow-hidden flex flex-col justify-between p-4">
                        {/* Vector path visualization */}
                        <svg className="absolute inset-0 w-full h-full opacity-60" viewBox="0 0 300 200">
                          {/* Grid roads */}
                          <line x1="20" y1="40" x2="280" y2="40" stroke="#333" strokeWidth="1" strokeDasharray="4 4" />
                          <line x1="20" y1="100" x2="280" y2="100" stroke="#333" strokeWidth="1" strokeDasharray="4 4" />
                          <line x1="20" y1="160" x2="280" y2="160" stroke="#333" strokeWidth="1" strokeDasharray="4 4" />
                          
                          {/* Route curve */}
                          <path
                            d="M 30,150 Q 120,40 270,80"
                            fill="none"
                            stroke="#555"
                            strokeWidth="3"
                          />
                          {/* Active completed route */}
                          <path
                            d="M 30,150 Q 120,40 270,80"
                            fill="none"
                            stroke="#D97706"
                            strokeWidth="3.5"
                            strokeDasharray="300"
                            strokeDashoffset={300 - (300 * activeTrackingOrder.courierGps.progressPercent) / 100}
                          />
                          
                          {/* Origin point */}
                          <circle cx="30" cy="150" r="5" fill="#FAF9F5" />
                          {/* Destination beacon */}
                          <circle cx="270" cy="80" r="6" fill="#10B981" />
                        </svg>

                        <div className="relative z-10 flex justify-between text-[10px] font-mono text-stone-400">
                          <span>FACILITY: SF CENTRAL</span>
                          <span className="text-white">ETA: TODAY</span>
                        </div>

                        {/* Interactive Courier Pin along path */}
                        <div className="relative z-10 my-auto">
                          <div className="flex justify-between text-[11px] text-stone-400 mb-1">
                            <span>Lab Facility</span>
                            <span>Your Destination</span>
                          </div>
                          <div className="w-full bg-stone-800 h-2 rounded-none relative overflow-hidden">
                            <div
                              className="bg-amber-400 h-full transition-all duration-700"
                              style={{ width: `${activeTrackingOrder.courierGps.progressPercent}%` }}
                            />
                          </div>
                          <div className="flex items-center justify-between text-[10px] font-mono text-stone-400 mt-2">
                            <span>TRANSIT PROGRESS</span>
                            <span className="text-amber-400 tabular-nums font-semibold">
                              {activeTrackingOrder.courierGps.progressPercent}%
                            </span>
                          </div>
                        </div>

                        {/* Atmospheric & Temperature telemetry */}
                        <div className="relative z-10 grid grid-cols-2 gap-2 text-[10px] font-mono p-2 bg-black/60 border border-stone-800">
                          <div className="flex items-center gap-1.5 text-stone-300">
                            <Thermometer className="w-3 h-3 text-cyan-400" />
                            <span>TEMP: 18.2°C (Optimal)</span>
                          </div>
                          <div className="flex items-center gap-1.5 text-emerald-400">
                            <CheckCircle2 className="w-3 h-3" />
                            <span>SEAL: UNCOMPROMISED</span>
                          </div>
                        </div>
                      </div>

                      <div className="text-[11px] text-stone-400 space-y-1 pt-1">
                        <div className="flex justify-between">
                          <span>Recipient:</span>
                          <span className="text-white">{activeTrackingOrder.shippingAddress.fullName}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Delivery Address:</span>
                          <span className="text-white text-right max-w-[200px] truncate">
                            {activeTrackingOrder.shippingAddress.street}, {activeTrackingOrder.shippingAddress.city}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Order Manifest */}
                    <div className="bg-white border border-stone-200 p-6 space-y-4">
                      <h4 className="text-xs uppercase tracking-widest font-semibold text-stone-900 border-b border-stone-200 pb-3">
                        Package Contents ({activeTrackingOrder.items.length})
                      </h4>

                      <div className="space-y-3">
                        {activeTrackingOrder.items.map((item, i) => (
                          <div key={i} className="flex gap-3 text-xs">
                            <img
                              src={item.product.image}
                              alt={item.product.name}
                              className="w-12 h-12 object-cover border border-stone-200 shrink-0"
                            />
                            <div className="flex-1 overflow-hidden">
                              <p className="font-semibold text-stone-900 truncate">{item.product.name}</p>
                              <div className="flex items-center gap-1.5 text-stone-500 mt-0.5">
                                <span
                                  className="w-2.5 h-2.5 rounded-full border border-stone-300"
                                  style={{ backgroundColor: item.selectedShade.hex }}
                                />
                                <span>{item.selectedShade.name}</span>
                                <span aria-hidden="true">·</span>
                                <span className="font-mono">Qty: {item.quantity}</span>
                              </div>
                            </div>
                            <span className="font-mono tabular-nums text-stone-900 font-medium">
                              ₹{(item.product.price * item.quantity).toLocaleString('en-IN')}
                            </span>
                          </div>
                        ))}
                      </div>

                      <div className="pt-3 border-t border-stone-100 flex justify-between text-xs font-semibold text-stone-900">
                        <span>Paid Total ({activeTrackingOrder.paymentMethod})</span>
                        <span className="font-mono tabular-nums">₹{activeTrackingOrder.total.toLocaleString('en-IN')}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* TAB 2: AURA GLOW CLUB (LOYALTY & REWARDS & MYSTERY VAULT) */}
      {/* ========================================================================= */}
      {activeTab === 'loyalty' && (
        <div className="space-y-12 animate-fadeIn">
          {/* Member Card & Tier Status */}
          <div className="bg-[#1C1917] text-white p-8 sm:p-12 border border-stone-800 grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
            <div className="md:col-span-7 space-y-4">
              <div className="flex items-center gap-2 text-xs uppercase tracking-widest font-semibold text-amber-400">
                <Sparkles className="w-4 h-4" />
                <span>Tier Status: {currentTier.name} Member</span>
              </div>

              <h2 className="text-3xl sm:text-4xl font-editorial font-medium">
                You have {loyaltyPoints} Glow Points
              </h2>

              <p className="text-xs sm:text-sm text-stone-300 leading-relaxed max-w-lg">
                Earn {currentTier.multiplier}x points for every ₹100 spent on clean formulas. Redeem points anytime for store credits, deluxe miniatures, or complimentary full-size pigments.
              </p>

              {/* Progress to Next Tier */}
              {nextTier ? (
                <div className="space-y-2 pt-2 max-w-md">
                  <div className="flex justify-between text-xs text-stone-300">
                    <span>Current: {currentTier.name}</span>
                    <span>Next: <strong>{nextTier.name}</strong> ({pointsToNext} pts away)</span>
                  </div>
                  <div className="w-full bg-stone-800 h-2 overflow-hidden">
                    <div
                      className="bg-amber-400 h-full transition-all duration-500"
                      style={{ width: `${progressToNext}%` }}
                    />
                  </div>
                </div>
              ) : (
                <p className="text-xs text-amber-300 font-semibold">
                  You have reached our highest VIP Atelier tier! Enjoy permanent white-glove benefits.
                </p>
              )}
            </div>

            {/* Daily Streak Card */}
            <div className="md:col-span-5 bg-stone-900 border border-stone-700 p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xs uppercase tracking-wider font-semibold text-stone-300">
                    Daily Glow Streak
                  </h3>
                  <p className="text-xl font-editorial font-bold text-white mt-0.5">
                    {dailyStreak} Consecutive Days
                  </p>
                </div>
                <div className="p-3 bg-amber-950/60 border border-amber-800/80 text-amber-400">
                  <Sparkles className="w-5 h-5" />
                </div>
              </div>

              <p className="text-xs text-stone-400 leading-relaxed">
                Check in once daily to earn +25 bonus points toward your next clean lipstick redemption.
              </p>

              <button
                onClick={claimDailyCheckIn}
                disabled={hasCheckedInToday}
                className={`w-full py-3 text-xs uppercase tracking-widest font-semibold transition-colors flex items-center justify-center gap-2 cursor-pointer ${
                  hasCheckedInToday
                    ? 'bg-stone-800 text-stone-500 cursor-not-allowed border border-stone-700'
                    : 'bg-white text-stone-900 hover:bg-stone-100'
                }`}
              >
                {hasCheckedInToday ? (
                  <>
                    <Check className="w-4 h-4 text-emerald-400" />
                    <span>Checked In for Today (+25 pts)</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-800" />
                    <span>Claim Today's +25 Glow Points</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Interactive Mystery Vault Unboxing Component */}
          <div className="bg-gradient-to-r from-stone-900 via-stone-850 to-stone-900 text-white p-8 border border-stone-700">
            <div className="flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="space-y-1 max-w-lg">
                <span className="text-[11px] uppercase tracking-widest font-semibold text-amber-400 flex items-center gap-1.5">
                  <Gift className="w-3.5 h-3.5" />
                  <span>The Daily Atelier Mystery Vault</span>
                </span>
                <h3 className="text-xl font-editorial font-semibold">
                  Unlock Today's Surprise Pigment Perk
                </h3>
                <p className="text-xs text-stone-300">
                  Open your member secret parcel to claim instant bonus points or limited-edition sample drops.
                </p>
              </div>

              {!mysteryOpened ? (
                <button
                  onClick={handleOpenMysteryVault}
                  className="px-6 py-3.5 bg-amber-400 text-stone-950 text-xs uppercase tracking-widest font-bold hover:bg-amber-300 transition-all transform hover:scale-105 shadow-xl cursor-pointer shrink-0"
                >
                  Open Mystery Vault ✦
                </button>
              ) : (
                <div className="p-4 bg-white/10 border border-amber-400/40 backdrop-blur-md flex items-center gap-4">
                  <div>
                    <p className="text-xs font-semibold text-amber-300">{mysteryGift?.title}</p>
                    <p className="text-[11px] text-stone-300">{mysteryGift?.desc}</p>
                  </div>
                  <div className="flex items-center gap-1.5 bg-black/60 px-2.5 py-1 text-xs font-mono text-white border border-stone-700">
                    <span>{mysteryGift?.code}</span>
                    <button
                      onClick={() => handleCopyCode(mysteryGift!.code)}
                      className="p-1 hover:text-amber-300"
                    >
                      <Copy className="w-3 h-3" />
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Tier Overview Grid */}
          <div className="space-y-4">
            <h3 className="text-xs uppercase tracking-widest font-semibold text-stone-500">
              Glow Club Tiers & Privileges
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {LOYALTY_TIERS.map(tier => {
                const isCurrent = tier.name === currentTier.name;
                return (
                  <div
                    key={tier.name}
                    className={`p-6 border transition-all ${
                      isCurrent
                        ? 'bg-white border-stone-900 shadow-md ring-1 ring-stone-900'
                        : 'bg-white/60 border-stone-200'
                    }`}
                  >
                    <div className="flex justify-between items-center mb-3">
                      <h4 className="text-sm font-semibold uppercase tracking-wider text-stone-900">
                        {tier.name}
                      </h4>
                      {isCurrent && (
                        <span className="text-[10px] uppercase font-mono font-bold bg-stone-900 text-white px-2 py-0.5">
                          Active Tier
                        </span>
                      )}
                    </div>

                    <p className="text-xs font-mono text-stone-500 mb-4">
                      {tier.minPoints === 0 ? 'Free Entry' : `${tier.minPoints}+ points`}
                    </p>

                    <ul className="space-y-2 text-xs text-stone-600">
                      {tier.perks.map((p, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <Check className="w-3.5 h-3.5 text-stone-900 shrink-0 mt-0.5" />
                          <span>{p}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Redeemable Rewards Catalog */}
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xs uppercase tracking-widest font-semibold text-stone-500">
                Redeemable Rewards Catalog
              </h3>
              <span className="text-xs font-mono text-stone-700">
                Balance: <strong>{loyaltyPoints} points</strong>
              </span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {LOYALTY_REWARDS.map(reward => {
                const canAfford = loyaltyPoints >= reward.pointsCost;
                const isRedeemed = redeemedRewards.includes(reward.id);

                return (
                  <div
                    key={reward.id}
                    className="bg-white border border-stone-200 p-6 flex flex-col justify-between space-y-4 transition-all hover:shadow-xs"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-mono font-semibold text-amber-800">
                          {reward.pointsCost} Points
                        </span>
                        {isRedeemed && (
                          <span className="text-[10px] uppercase tracking-wider bg-stone-100 text-stone-700 px-2 py-0.5">
                            Redeemed
                          </span>
                        )}
                      </div>

                      <h4 className="font-editorial text-lg font-semibold text-stone-900 mt-2">
                        {reward.title}
                      </h4>
                      <p className="text-xs text-stone-500 mt-1 leading-relaxed">
                        {reward.description}
                      </p>
                    </div>

                    <div className="pt-4 border-t border-stone-100 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-mono bg-stone-100 px-2.5 py-1 text-stone-800 border border-stone-200 select-all">
                          {reward.discountCode}
                        </span>
                        <button
                          onClick={() => handleCopyCode(reward.discountCode)}
                          className="p-1 text-stone-400 hover:text-stone-800 cursor-pointer"
                          title="Copy promo code"
                        >
                          {copiedCode === reward.discountCode ? (
                            <Check className="w-3.5 h-3.5 text-emerald-600" />
                          ) : (
                            <Copy className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>

                      <button
                        onClick={() => {
                          sound.playChime();
                          redeemReward(reward.id);
                        }}
                        disabled={!canAfford}
                        className={`px-4 py-2 text-xs uppercase tracking-wider font-semibold transition-colors cursor-pointer ${
                          canAfford
                            ? 'bg-stone-900 text-white hover:bg-stone-800'
                            : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                        }`}
                      >
                        {canAfford ? 'Redeem & Apply' : 'Need More Points'}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Referral Card */}
          <div className="bg-[#FAF7F0] border border-stone-300 p-8 flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-1">
              <span className="text-xs uppercase tracking-widest font-semibold text-stone-500">
                Atelier Referral Circle
              </span>
              <h3 className="text-xl font-editorial font-medium text-stone-900">
                Give ₹500, Get +150 Glow Points
              </h3>
              <p className="text-xs text-stone-600 max-w-lg">
                Share your personal code with clean beauty enthusiasts. When they make their first order, they receive ₹500 off and you receive 150 points.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <span className="px-4 py-2.5 bg-white border border-stone-300 font-mono text-xs font-semibold text-stone-900">
                AUR-ELENA-GLOW
              </span>
              <button
                onClick={() => handleCopyCode('AUR-ELENA-GLOW')}
                className="px-4 py-2.5 bg-stone-900 text-white text-xs uppercase tracking-wider font-medium hover:bg-stone-800 transition-colors cursor-pointer"
              >
                {copiedCode === 'AUR-ELENA-GLOW' ? 'Copied!' : 'Copy Code'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
