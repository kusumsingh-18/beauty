import { Product, LoyaltyReward, LoyaltyTier } from '../types';

export const HERO_CAMPAIGN_IMG = '/src/assets/images/hero_beauty_editorial_1791193401127.jpg';
export const LIP_PRODUCT_IMG = '/src/assets/images/product_lip_velvet_1791193419141.jpg';
export const FOUNDATION_PRODUCT_IMG = '/src/assets/images/product_silk_foundation_1791193431506.jpg';
export const BLUSH_PRODUCT_IMG = '/src/assets/images/product_cream_blush_1791193445236.jpg';
export const TRYON_MODEL_IMG = '/src/assets/images/virtual_tryon_model_1791193454610.jpg';

export const PRODUCTS: Product[] = [
  {
    id: 'aura-velvet-lip',
    name: 'Suede Rouge Botanical Liquid Velvet',
    subtitle: 'Nourishing squalane-infused whipped matte lip pigment',
    category: 'Lips',
    price: 1650,
    rating: 4.9,
    reviewCount: 428,
    image: LIP_PRODUCT_IMG,
    description: 'A weightless, cloud-like liquid pigment that delivers comfortable 12-hour velvet color without drying. Formulated with organic plant squalane and damask rose oil to plump, hydrate, and soften lips with every wear.',
    certifications: ['Vegan', 'Cruelty-Free', 'Fragrance-Free', 'Paraben-Free'],
    suitableSkinTypes: ['Normal', 'Dry', 'Combination', 'Oily', 'Sensitive'],
    suitableSkinTones: ['Fair', 'Light', 'Medium', 'Tan', 'Deep', 'Rich'],
    tryOnType: 'lips',
    isBestSeller: true,
    isNewArrival: false,
    shades: [
      { id: 'v-01', name: 'Alabaster Rose', hex: '#C27474', finish: 'Velvet Matte', skinToneMatch: ['Fair', 'Light'], undertoneMatch: ['Cool', 'Neutral'] },
      { id: 'v-02', name: 'Terracotta Dawn', hex: '#BA5D4A', finish: 'Velvet Matte', skinToneMatch: ['Medium', 'Tan'], undertoneMatch: ['Warm', 'Olive'] },
      { id: 'v-03', name: 'Bordeaux Noir', hex: '#722530', finish: 'Velvet Matte', skinToneMatch: ['Tan', 'Deep', 'Rich'], undertoneMatch: ['Cool', 'Neutral', 'Warm'] },
      { id: 'v-04', name: 'Nude Praline', hex: '#AD7967', finish: 'Velvet Matte', skinToneMatch: ['Light', 'Medium', 'Tan'], undertoneMatch: ['Neutral', 'Warm'] },
      { id: 'v-05', name: 'Petal Glaze', hex: '#D88A8A', finish: 'Dewy Gloss', skinToneMatch: ['Fair', 'Light', 'Medium'], undertoneMatch: ['Cool', 'Neutral'] },
      { id: 'v-06', name: 'Spiced Dahlia', hex: '#943842', finish: 'Velvet Matte', skinToneMatch: ['Medium', 'Deep', 'Rich'], undertoneMatch: ['Warm', 'Neutral'] }
    ],
    ingredients: [
      { name: 'Olive-Derived Squalane', benefit: 'Locks in deep intercellular lip moisture', isKeyActive: true },
      { name: 'Cold-Pressed Damask Rose Oil', benefit: 'Rich in fatty acids and antioxidants', isKeyActive: true },
      { name: 'Hyaluronic Acid Spheres', benefit: 'Micro-filling hydration for smoother lip volume', isKeyActive: true },
      { name: 'Tocopherol (Vitamin E)', benefit: 'Defends delicate lips from environmental stress' },
      { name: 'Organic Jojoba Seed Oil', benefit: 'Bio-compatible nourishing emollient' }
    ]
  },
  {
    id: 'aura-silk-foundation',
    name: 'Skin Luminary Serum Elixir Foundation',
    subtitle: 'Niacinamide + Peptide breathable second-skin tint SPF 25',
    category: 'Complexion',
    price: 2850,
    rating: 4.95,
    reviewCount: 684,
    image: FOUNDATION_PRODUCT_IMG,
    description: 'An intelligent hybrid treatment foundation that fuses high-purity mineral pigments with 4% niacinamide and botanical peptides. Delivers buildable satin-radiant coverage while visibly refining pore texture and calming redness.',
    certifications: ['Vegan', 'Cruelty-Free', 'Paraben-Free', 'Silicone-Free', 'Non-Comedogenic'],
    suitableSkinTypes: ['Normal', 'Dry', 'Combination', 'Oily', 'Sensitive'],
    suitableSkinTones: ['Fair', 'Light', 'Medium', 'Tan', 'Deep', 'Rich'],
    tryOnType: 'complexion',
    isBestSeller: true,
    isNewArrival: false,
    shades: [
      { id: 'f-10', name: 'Porcelain 100 - Cool', hex: '#F6E6DA', finish: 'Silk Satin', skinToneMatch: ['Fair'], undertoneMatch: ['Cool'] },
      { id: 'f-15', name: 'Alabaster 150 - Neutral', hex: '#F0DEC8', finish: 'Silk Satin', skinToneMatch: ['Fair', 'Light'], undertoneMatch: ['Neutral'] },
      { id: 'f-20', name: 'Buff 200 - Warm', hex: '#E6CFB3', finish: 'Silk Satin', skinToneMatch: ['Light'], undertoneMatch: ['Warm'] },
      { id: 'f-30', name: 'Golden Honey 300 - Warm', hex: '#D6B48E', finish: 'Silk Satin', skinToneMatch: ['Medium'], undertoneMatch: ['Warm', 'Olive'] },
      { id: 'f-35', name: 'Amber Dune 350 - Neutral', hex: '#C69D73', finish: 'Silk Satin', skinToneMatch: ['Medium', 'Tan'], undertoneMatch: ['Neutral'] },
      { id: 'f-40', name: 'Sienna Dusk 400 - Warm', hex: '#A87950', finish: 'Silk Satin', skinToneMatch: ['Tan', 'Deep'], undertoneMatch: ['Warm'] },
      { id: 'f-50', name: 'Espresso Velvet 500 - Neutral', hex: '#634027', finish: 'Silk Satin', skinToneMatch: ['Deep', 'Rich'], undertoneMatch: ['Neutral', 'Cool'] },
      { id: 'f-60', name: 'Obsidian Rich 600 - Warm', hex: '#3B2317', finish: 'Silk Satin', skinToneMatch: ['Rich'], undertoneMatch: ['Warm', 'Neutral'] }
    ],
    ingredients: [
      { name: '4% Niacinamide (Vitamin B3)', benefit: 'Smooths surface texture and regulates sebum', isKeyActive: true },
      { name: 'Hexapeptide-8 Complex', benefit: 'Firms skin bounce and reduces expression lines', isKeyActive: true },
      { name: 'Snow Mushroom Extract', benefit: 'Holds 500x its weight in moisture for continuous bounce', isKeyActive: true },
      { name: 'Zinc Oxide (Non-Nano)', benefit: 'Gentle mineral barrier defense' },
      { name: 'Camellia Sinensis Leaf Water', benefit: 'Soothes inflammation and oxidative stress' }
    ]
  },
  {
    id: 'aura-melt-blush',
    name: 'Petal Flush Nourishing Cream Pot',
    subtitle: 'Lip-to-cheek dewy balm with rosehip & peptide glow',
    category: 'Cheeks',
    price: 1850,
    rating: 4.88,
    reviewCount: 312,
    image: BLUSH_PRODUCT_IMG,
    description: 'A multi-use melt-in-skin cream pigment housed in an architectural brass and matte ivory compact. Warms with finger touch for seamless blending across cheekbones and eyelids for an effortless monochromatic editorial glow.',
    certifications: ['Vegan', 'Cruelty-Free', 'Fragrance-Free', 'Silicone-Free'],
    suitableSkinTypes: ['Normal', 'Dry', 'Combination', 'Sensitive'],
    suitableSkinTones: ['Fair', 'Light', 'Medium', 'Tan', 'Deep', 'Rich'],
    tryOnType: 'cheeks',
    isBestSeller: true,
    isNewArrival: true,
    shades: [
      { id: 'b-01', name: 'Nectarine Glow', hex: '#E7856B', finish: 'Dewy Gloss', skinToneMatch: ['Fair', 'Light', 'Medium'], undertoneMatch: ['Warm', 'Neutral'] },
      { id: 'b-02', name: 'Wild Fig', hex: '#A34F5C', finish: 'Dewy Gloss', skinToneMatch: ['Medium', 'Tan', 'Deep'], undertoneMatch: ['Cool', 'Neutral'] },
      { id: 'b-03', name: 'Sunlit Ochre', hex: '#C97753', finish: 'Silk Satin', skinToneMatch: ['Light', 'Medium', 'Tan'], undertoneMatch: ['Warm', 'Olive'] },
      { id: 'b-04', name: 'Blackberry Mist', hex: '#6D2B3F', finish: 'Dewy Gloss', skinToneMatch: ['Tan', 'Deep', 'Rich'], undertoneMatch: ['Cool', 'Warm'] }
    ],
    ingredients: [
      { name: 'Organic Cold-Pressed Rosehip Seed Oil', benefit: 'Rich in Pro-Vitamin A and Linoleic acid', isKeyActive: true },
      { name: 'Murumuru Seed Butter', benefit: 'Restores skin lipid envelope without heaviness', isKeyActive: true },
      { name: 'Ethical Mineral Mica', benefit: 'Imparts soft-focus dimensional luminosity', isKeyActive: true },
      { name: 'Elderberry Fruit Extract', benefit: 'Natural clean antioxidant preservative' }
    ]
  },
  {
    id: 'aura-glass-glaze',
    name: 'Lucent Crystalline Peptide Glaze',
    subtitle: 'Multi-dimensional non-sticky liquid highlighter',
    category: 'Cheeks',
    price: 1950,
    rating: 4.92,
    reviewCount: 198,
    image: HERO_CAMPAIGN_IMG,
    description: 'A breakthrough high-refractive glass elixir that mimics post-facial moisture. Zero chunky glitter—only micro-milled crystalline pearls suspended in a hyaluronic botanical cushion.',
    certifications: ['Vegan', 'Cruelty-Free', 'Paraben-Free', 'Fragrance-Free'],
    suitableSkinTypes: ['Normal', 'Dry', 'Combination', 'Oily', 'Sensitive'],
    suitableSkinTones: ['Fair', 'Light', 'Medium', 'Tan', 'Deep', 'Rich'],
    tryOnType: 'cheeks',
    isBestSeller: false,
    isNewArrival: true,
    shades: [
      { id: 'g-01', name: 'Champagne Quartz', hex: '#EFE3D0', finish: 'Luminous Shimmer', skinToneMatch: ['Fair', 'Light', 'Medium'], undertoneMatch: ['Neutral', 'Warm'] },
      { id: 'g-02', name: 'Rose Aurora', hex: '#EAC2BE', finish: 'Luminous Shimmer', skinToneMatch: ['Fair', 'Light'], undertoneMatch: ['Cool', 'Neutral'] },
      { id: 'g-03', name: 'Bronze Solstice', hex: '#BD895E', finish: 'Luminous Shimmer', skinToneMatch: ['Medium', 'Tan', 'Deep', 'Rich'], undertoneMatch: ['Warm', 'Olive'] }
    ],
    ingredients: [
      { name: 'Oligo-Hyaluronic Acid', benefit: 'Deep low-molecular weight moisture binding', isKeyActive: true },
      { name: 'Fermented Green Tea Seed Oil', benefit: 'Non-comedogenic barrier restoration', isKeyActive: true },
      { name: 'Light-Reflecting Pearlite', benefit: 'Natural mineral shimmer with 360-degree deflection' }
    ]
  },
  {
    id: 'aura-cashmere-palette',
    name: 'Atelier Mineral Cashmere Eye Quad',
    subtitle: 'Velvety wet-to-dry mineral pigments with bakuchiol',
    category: 'Eyes',
    price: 2650,
    rating: 4.87,
    reviewCount: 154,
    image: BLUSH_PRODUCT_IMG,
    description: 'Four finely pressed mineral shadows featuring silk-binding agents that glide like cream without creasing. Infused with bakuchiol to nourish the delicate ocular contours.',
    certifications: ['Vegan', 'Cruelty-Free', 'Fragrance-Free', 'Paraben-Free'],
    suitableSkinTypes: ['Normal', 'Dry', 'Combination', 'Oily', 'Sensitive'],
    suitableSkinTones: ['Fair', 'Light', 'Medium', 'Tan', 'Deep', 'Rich'],
    tryOnType: 'eyes',
    isBestSeller: false,
    isNewArrival: true,
    shades: [
      { id: 'e-01', name: 'Earth & Alabaster Palette', hex: '#8F6652', finish: 'Silk Satin', skinToneMatch: ['Fair', 'Light', 'Medium', 'Tan', 'Deep', 'Rich'], undertoneMatch: ['Neutral', 'Warm'] },
      { id: 'e-02', name: 'Smoky Amethyst Palette', hex: '#634B59', finish: 'Silk Satin', skinToneMatch: ['Fair', 'Light', 'Medium', 'Tan', 'Deep', 'Rich'], undertoneMatch: ['Cool', 'Neutral'] }
    ],
    ingredients: [
      { name: '1% Botanical Bakuchiol', benefit: 'Gentle retinol alternative for eyelid smoothing', isKeyActive: true },
      { name: 'Hydrolyzed Rice Protein', benefit: 'Strengthens lash roots and primes eyelid skin', isKeyActive: true },
      { name: 'Kaolin Clay (Purified)', benefit: 'Absorbs excess lid oils for 14-hour crease-free wear' }
    ]
  },
  {
    id: 'aura-barrier-nectar',
    name: 'Cellular Prime Hydrating Nectar',
    subtitle: 'Ceramide 3 + Squalane pre-makeup barrier defense',
    category: 'Hybrid Care',
    price: 2950,
    rating: 4.97,
    reviewCount: 520,
    image: FOUNDATION_PRODUCT_IMG,
    description: 'A silky biphasic primer and treatment elixir that creates an ultra-smooth canvas for pigments while reinforcing skin barrier resilience all day long.',
    certifications: ['Vegan', 'Cruelty-Free', 'Fragrance-Free', 'Paraben-Free', 'Silicone-Free'],
    suitableSkinTypes: ['Normal', 'Dry', 'Combination', 'Sensitive'],
    suitableSkinTones: ['Fair', 'Light', 'Medium', 'Tan', 'Deep', 'Rich'],
    isBestSeller: true,
    isNewArrival: false,
    shades: [
      { id: 'n-01', name: 'Translucent Dew', hex: '#FAF6EE', finish: 'Dewy Gloss', skinToneMatch: ['Fair', 'Light', 'Medium', 'Tan', 'Deep', 'Rich'] }
    ],
    ingredients: [
      { name: 'Bio-Identical Ceramide NP', benefit: 'Rebuilds skin lipid architecture', isKeyActive: true },
      { name: 'Centella Asiatica (Cica)', benefit: 'Rapidly calms redness and reactive flare-ups', isKeyActive: true },
      { name: 'Phytosqualane', benefit: 'Imparts immediate glass-skin slip and suppleness', isKeyActive: true }
    ]
  }
];

export const ALL_KEY_INGREDIENTS = [
  'Olive-Derived Squalane',
  '4% Niacinamide (Vitamin B3)',
  'Hexapeptide-8 Complex',
  'Hyaluronic Acid Spheres',
  'Organic Cold-Pressed Rosehip Seed Oil',
  '1% Botanical Bakuchiol',
  'Bio-Identical Ceramide NP',
  'Centella Asiatica (Cica)',
  'Snow Mushroom Extract'
];

export const LOYALTY_TIERS: LoyaltyTier[] = [
  {
    name: 'Bronze',
    minPoints: 0,
    multiplier: 1.0,
    perks: ['1 point per ₹100 spent', 'Complimentary birthday miniature', 'Early access to seasonal drops'],
    badgeColor: '#A37D57'
  },
  {
    name: 'Silver',
    minPoints: 300,
    multiplier: 1.25,
    perks: ['1.25 points per ₹100 spent', 'Free express domestic shipping on ₹1,999+', 'Virtual beauty consultation booking', '2x points on Clean Beauty Day'],
    badgeColor: '#9CA3AF'
  },
  {
    name: 'Gold',
    minPoints: 750,
    multiplier: 1.5,
    perks: ['1.5 points per ₹100 spent', 'Free priority delivery on all orders', 'Custom engraved lipstick caps', 'Invitations to virtual masterclasses'],
    badgeColor: '#D97706'
  },
  {
    name: 'VIP Atelier',
    minPoints: 1500,
    multiplier: 2.0,
    perks: ['2.0 points per ₹100 spent', 'Private preview sample drops before launch', 'Complimentary full-size anniversary gift', 'Direct WhatsApp Atelier concierge'],
    badgeColor: '#1C1917'
  }
];

export const LOYALTY_REWARDS: LoyaltyReward[] = [
  {
    id: 'rew-10',
    title: '₹500 Off Your Next Order',
    description: 'Applicable to any purchase above ₹1,999 across the entire catalog.',
    pointsCost: 200,
    discountCode: 'GLOW500',
    type: 'discount',
    discountAmount: 500
  },
  {
    id: 'rew-lip',
    title: 'Free Velvet Liquid Lip in Custom Shade',
    description: 'Redeem for a full-size Suede Rouge in your shade of choice.',
    pointsCost: 450,
    discountCode: 'FREELIPVELVET',
    type: 'free_product',
    discountAmount: 1650
  },
  {
    id: 'rew-25',
    title: '₹1,200 Atelier Credit',
    description: 'Generous credit toward foundation matching or multi-pot sets.',
    pointsCost: 600,
    discountCode: 'GLOW1200',
    type: 'discount',
    discountAmount: 1200
  },
  {
    id: 'rew-deluxe',
    title: 'Complimentary Mulberry Silk Pouch & Minis',
    description: 'Curated 3-piece luxury travel kit with hand-stitched organic silk pouch.',
    pointsCost: 800,
    discountCode: 'SILKMINISET',
    type: 'free_product'
  }
];
