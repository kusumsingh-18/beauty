export type SkinToneCategory = 'Fair' | 'Light' | 'Medium' | 'Tan' | 'Deep' | 'Rich';
export type Undertone = 'Cool' | 'Warm' | 'Neutral' | 'Olive';
export type SkinType = 'Oily' | 'Dry' | 'Combination' | 'Normal' | 'Sensitive';

export interface Shade {
  id: string;
  name: string;
  hex: string;
  finish: 'Velvet Matte' | 'Dewy Gloss' | 'Silk Satin' | 'Luminous Shimmer';
  skinToneMatch?: SkinToneCategory[];
  undertoneMatch?: Undertone[];
}

export interface Ingredient {
  name: string;
  benefit: string;
  isKeyActive?: boolean;
}

export interface Product {
  id: string;
  name: string;
  subtitle: string;
  category: 'Lips' | 'Complexion' | 'Cheeks' | 'Eyes' | 'Hybrid Care';
  price: number;
  rating: number;
  reviewCount: number;
  image: string;
  description: string;
  shades: Shade[];
  ingredients: Ingredient[];
  certifications: ('Vegan' | 'Cruelty-Free' | 'Paraben-Free' | 'Fragrance-Free' | 'Silicone-Free' | 'Non-Comedogenic')[];
  suitableSkinTypes: SkinType[];
  suitableSkinTones: SkinToneCategory[];
  tryOnType?: 'lips' | 'cheeks' | 'complexion' | 'eyes';
  isBestSeller?: boolean;
  isNewArrival?: boolean;
}

export interface CartItem {
  product: Product;
  selectedShade: Shade;
  quantity: number;
}

export interface SkinDiagnosticResult {
  skinTone: SkinToneCategory;
  undertone: Undertone;
  skinType: SkinType;
  concerns: string[];
  recommendedProductIds: string[];
  customRoutine: {
    step: number;
    title: string;
    productName: string;
    reason: string;
  }[];
}

export interface LoyaltyTier {
  name: 'Bronze' | 'Silver' | 'Gold' | 'VIP Atelier';
  minPoints: number;
  multiplier: number;
  perks: string[];
  badgeColor: string;
}

export interface LoyaltyReward {
  id: string;
  title: string;
  description: string;
  pointsCost: number;
  discountCode: string;
  type: 'discount' | 'free_product' | 'shipping';
  discountAmount?: number;
}

export interface OrderTrackingStep {
  status: 'Order Placed' | 'Cold-Pressed Batching' | 'Purity & QC Passed' | 'Dispatched' | 'Out for Delivery' | 'Delivered';
  location: string;
  timestamp: string;
  completed: boolean;
  active: boolean;
  note?: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  createdAt: string;
  items: CartItem[];
  subtotal: number;
  discount: number;
  shipping: number;
  total: number;
  paymentMethod: string;
  shippingAddress: {
    fullName: string;
    street: string;
    city: string;
    state: string;
    zip: string;
  };
  trackingNumber: string;
  carrier: string;
  estimatedDelivery: string;
  currentStepIndex: number;
  steps: OrderTrackingStep[];
  courierGps: {
    lat: number;
    lng: number;
    progressPercent: number;
  };
}

export interface NotificationItem {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'arrival' | 'drop' | 'order' | 'loyalty';
  unread: boolean;
  actionUrl?: string;
}
