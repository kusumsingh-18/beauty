import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { QuickViewModal } from './components/QuickViewModal';
import { ShadeMixerModal } from './components/ShadeMixerModal';
import { IngredientDeepDiveModal } from './components/IngredientDeepDiveModal';
import { HomePage } from './pages/HomePage';
import { ShopPage } from './pages/ShopPage';
import { VirtualTryOnPage } from './pages/VirtualTryOnPage';
import { DiagnosticPage } from './pages/DiagnosticPage';
import { LoyaltyAndTrackingPage } from './pages/LoyaltyAndTrackingPage';
import { Sparkles, X, Bell } from 'lucide-react';

const MainLayout: React.FC = () => {
  const {
    currentPage,
    toastMessage,
    dismissToast,
    isShadeMixerOpen,
    setIsShadeMixerOpen,
    selectedIngredientForModal,
    setSelectedIngredientForModal
  } = useApp();

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF9F5] text-stone-900 selection:bg-stone-900 selection:text-white relative">
      {/* Top Navbar */}
      <Navbar />

      {/* Main 5-Page Content Routing */}
      <main className="flex-1">
        {currentPage === 'home' && <HomePage />}
        {currentPage === 'shop' && <ShopPage />}
        {currentPage === 'tryon' && <VirtualTryOnPage />}
        {currentPage === 'diagnostic' && <DiagnosticPage />}
        {currentPage === 'loyalty-orders' && <LoyaltyAndTrackingPage />}
      </main>

      {/* Global Interactive Drawers & Modals */}
      <CartDrawer />
      <CheckoutModal />
      <QuickViewModal />
      <ShadeMixerModal
        isOpen={isShadeMixerOpen}
        onClose={() => setIsShadeMixerOpen(false)}
      />
      <IngredientDeepDiveModal
        ingredientName={selectedIngredientForModal}
        onClose={() => setSelectedIngredientForModal(null)}
      />

      {/* Footer */}
      <Footer />

      {/* Real-Time Push Notification & Event Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 max-w-sm bg-stone-950 text-white p-4 shadow-2xl border border-stone-800 flex items-start gap-3 animate-bounce-subtle">
          <div className="p-1.5 bg-stone-800 text-amber-400 shrink-0 mt-0.5">
            <Bell className="w-4 h-4" />
          </div>
          <div className="flex-1">
            <h4 className="text-xs uppercase tracking-wider font-semibold text-white">
              {toastMessage.text}
            </h4>
            {toastMessage.sub && (
              <p className="text-xs text-stone-400 mt-0.5 leading-snug">{toastMessage.sub}</p>
            )}
          </div>
          <button
            onClick={dismissToast}
            className="text-stone-500 hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainLayout />
    </AppProvider>
  );
}
