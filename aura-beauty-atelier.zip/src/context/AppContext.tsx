import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, Shade, CartItem, Order, NotificationItem, SkinDiagnosticResult } from '../types';
import { PRODUCTS, LOYALTY_REWARDS } from '../data/products';
import { sound } from '../utils/audio';

interface CheckoutDetails {
  fullName: string;
  email: string;
  street: string;
  city: string;
  state: string;
  zip: string;
  paymentMethod: string;
  cardNumber?: string;
}

interface AppContextType {
  currentPage: string;
  setCurrentPage: (page: string) => void;
  cart: CartItem[];
  addToCart: (product: Product, shade: Shade, quantity?: number) => void;
  removeFromCart: (productId: string, shadeId: string) => void;
  updateQuantity: (productId: string, shadeId: string, quantity: number) => void;
  clearCart: () => void;
  cartSubtotal: number;
  cartDiscount: number;
  cartShipping: number;
  cartTotal: number;
  cartCount: number;
  isCartOpen: boolean;
  setIsCartOpen: (open: boolean) => void;
  appliedDiscountCode: string | null;
  applyDiscountCode: (code: string) => { success: boolean; message: string };
  removeDiscountCode: () => void;
  loyaltyPoints: number;
  addLoyaltyPoints: (amount: number) => void;
  dailyStreak: number;
  hasCheckedInToday: boolean;
  claimDailyCheckIn: () => { success: boolean; pointsEarned: number };
  redeemedRewards: string[];
  redeemReward: (rewardId: string) => { success: boolean; message: string };
  orders: Order[];
  activeTrackingOrder: Order | null;
  setActiveTrackingOrder: (order: Order | null) => void;
  advanceOrderSimulation: (orderId: string) => void;
  notifications: NotificationItem[];
  unreadNotificationCount: number;
  markNotificationsAsRead: () => void;
  pushNotificationsEnabled: boolean;
  togglePushNotifications: () => void;
  triggerPushNotification: (title: string, message: string, type: 'arrival' | 'drop' | 'order' | 'loyalty', actionUrl?: string) => void;
  userSkinProfile: SkinDiagnosticResult | null;
  setUserSkinProfile: (profile: SkinDiagnosticResult | null) => void;
  quickViewProduct: Product | null;
  setQuickViewProduct: (product: Product | null) => void;
  isCheckoutOpen: boolean;
  setIsCheckoutOpen: (open: boolean) => void;
  isShadeMixerOpen: boolean;
  setIsShadeMixerOpen: (open: boolean) => void;
  selectedIngredientForModal: string | null;
  setSelectedIngredientForModal: (name: string | null) => void;
  isSoundEnabled: boolean;
  toggleSound: () => void;
  createOrder: (details: CheckoutDetails) => Order;
  toastMessage: { id: string; text: string; sub?: string } | null;
  dismissToast: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

const INITIAL_ORDER: Order = {
  id: 'ord-849201',
  orderNumber: 'AUR-849201',
  createdAt: '2026-10-04 14:22',
  items: [
    {
      product: PRODUCTS[0],
      selectedShade: PRODUCTS[0].shades[0],
      quantity: 1
    },
    {
      product: PRODUCTS[2],
      selectedShade: PRODUCTS[2].shades[0],
      quantity: 1
    }
  ],
  subtotal: 3500,
  discount: 500,
  shipping: 0,
  total: 3000,
  paymentMethod: 'UPI / Google Pay (Verified)',
  shippingAddress: {
    fullName: 'Aanya Sharma',
    street: '402 Regency Towers, Pali Hill',
    city: 'Mumbai',
    state: 'Maharashtra',
    zip: '400050'
  },
  trackingNumber: 'AUR-EXP-99214482',
  carrier: 'BlueDart Express Luxury Air Courier',
  estimatedDelivery: 'Tomorrow by 2:00 PM',
  currentStepIndex: 3, // Dispatched
  courierGps: {
    lat: 19.0760,
    lng: 72.8777,
    progressPercent: 68
  },
  steps: [
    {
      status: 'Order Placed',
      location: 'Mumbai Digital Atelier',
      timestamp: 'Yesterday at 2:22 PM',
      completed: true,
      active: false,
      note: 'Payment authorized via UPI and receipt dispatched'
    },
    {
      status: 'Cold-Pressed Batching',
      location: 'Aura Lab & Formulation Suite, Bengaluru',
      timestamp: 'Yesterday at 4:45 PM',
      completed: true,
      active: false,
      note: 'Hand-blended squalane & botanical pigments sealed in amber vials'
    },
    {
      status: 'Purity & QC Passed',
      location: 'Clean Cosmetic Cleanroom, Hyderabad',
      timestamp: 'Today at 8:15 AM',
      completed: true,
      active: false,
      note: 'Microbiological purity 100% verified, cruelty-free certification sealed'
    },
    {
      status: 'Dispatched',
      location: 'Mumbai Transit Distribution Hub',
      timestamp: 'Today at 10:30 AM',
      completed: true,
      active: true,
      note: 'In transit with temperature-controlled courier vehicle'
    },
    {
      status: 'Out for Delivery',
      location: 'Bandra West Local Depot',
      timestamp: 'Expected Tomorrow at 9:00 AM',
      completed: false,
      active: false,
      note: 'Assigned to white-glove eco courier'
    },
    {
      status: 'Delivered',
      location: 'Recipient Address Doorstep',
      timestamp: 'Expected Tomorrow at 2:00 PM',
      completed: false,
      active: false,
      note: 'Contactless delivery with signature option'
    }
  ]
};

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [cart, setCart] = useState<CartItem[]>([
    {
      product: PRODUCTS[0],
      selectedShade: PRODUCTS[0].shades[0],
      quantity: 1
    }
  ]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [appliedDiscountCode, setAppliedDiscountCode] = useState<string | null>(null);
  const [loyaltyPoints, setLoyaltyPoints] = useState<number>(540);
  const [dailyStreak, setDailyStreak] = useState<number>(4);
  const [hasCheckedInToday, setHasCheckedInToday] = useState<boolean>(false);
  const [redeemedRewards, setRedeemedRewards] = useState<string[]>([]);
  const [orders, setOrders] = useState<Order[]>([INITIAL_ORDER]);
  const [activeTrackingOrder, setActiveTrackingOrder] = useState<Order | null>(INITIAL_ORDER);
  const [pushNotificationsEnabled, setPushNotificationsEnabled] = useState<boolean>(true);
  const [userSkinProfile, setUserSkinProfile] = useState<SkinDiagnosticResult | null>(null);
  const [quickViewProduct, setQuickViewProduct] = useState<Product | null>(null);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState<boolean>(false);
  const [isShadeMixerOpen, setIsShadeMixerOpen] = useState<boolean>(false);
  const [selectedIngredientForModal, setSelectedIngredientForModal] = useState<string | null>(null);
  const [isSoundEnabled, setIsSoundEnabled] = useState<boolean>(true);
  const [toastMessage, setToastMessage] = useState<{ id: string; text: string; sub?: string } | null>(null);

  const toggleSound = () => {
    const next = !isSoundEnabled;
    setIsSoundEnabled(next);
    sound.enabled = next;
    if (next) sound.playClick();
  };

  const [notifications, setNotifications] = useState<NotificationItem[]>([
    {
      id: 'notif-1',
      title: 'New Shade Drop: Spiced Dahlia',
      message: 'The cult favorite Suede Rouge liquid velvet is now available in rich berry spiced dahlia.',
      timestamp: '15m ago',
      type: 'arrival',
      unread: true,
      actionUrl: 'shop'
    },
    {
      id: 'notif-2',
      title: 'Order AUR-849201 In Transit',
      message: 'Your temperature-controlled clean beauty parcel is en route via DHL Express.',
      timestamp: '2h ago',
      type: 'order',
      unread: true,
      actionUrl: 'loyalty-orders'
    },
    {
      id: 'notif-3',
      title: 'Glow Tier Silver Unlocked',
      message: 'You have earned 540 Aura Points. Redeem your ₹500 reward anytime.',
      timestamp: '1d ago',
      type: 'loyalty',
      unread: false,
      actionUrl: 'loyalty-orders'
    }
  ]);

  // Toast auto-dismiss
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => {
        setToastMessage(null);
      }, 4500);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  const showToast = (text: string, sub?: string) => {
    setToastMessage({
      id: Date.now().toString(),
      text,
      sub
    });
  };

  const dismissToast = () => {
    setToastMessage(null);
  };

  const addToCart = (product: Product, shade: Shade, quantity = 1) => {
    setCart(prev => {
      const existingIndex = prev.findIndex(
        item => item.product.id === product.id && item.selectedShade.id === shade.id
      );
      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex].quantity += quantity;
        return next;
      } else {
        return [...prev, { product, selectedShade: shade, quantity }];
      }
    });
    showToast(`Added to Bag`, `${product.name} · ${shade.name}`);
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string, shadeId: string) => {
    setCart(prev => prev.filter(
      item => !(item.product.id === productId && item.selectedShade.id === shadeId)
    ));
  };

  const updateQuantity = (productId: string, shadeId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId, shadeId);
      return;
    }
    setCart(prev =>
      prev.map(item =>
        item.product.id === productId && item.selectedShade.id === shadeId
          ? { ...item, quantity }
          : item
      )
    );
  };

  const clearCart = () => {
    setCart([]);
  };

  const cartSubtotal = cart.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  let cartDiscount = 0;
  if (appliedDiscountCode === 'GLOW500' || appliedDiscountCode === 'GLOW10OFF') cartDiscount = 500;
  else if (appliedDiscountCode === 'GLOW1200' || appliedDiscountCode === 'GLOW25CREDIT') cartDiscount = 1200;
  else if (appliedDiscountCode === 'FREELIPVELVET') cartDiscount = 1650;
  else if (appliedDiscountCode === 'WELCOME15') cartDiscount = Math.round(cartSubtotal * 0.15);

  cartDiscount = Math.min(cartDiscount, cartSubtotal);
  const cartShipping = cartSubtotal >= 1999 || cartSubtotal === 0 ? 0 : 150;
  const cartTotal = Math.max(0, cartSubtotal - cartDiscount + cartShipping);
  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  const applyDiscountCode = (code: string) => {
    const trimmed = code.trim().toUpperCase();
    if (
      trimmed === 'GLOW500' ||
      trimmed === 'GLOW1200' ||
      trimmed === 'FREELIPVELVET' ||
      trimmed === 'WELCOME15' ||
      trimmed === 'MYSTERYGLAZE50'
    ) {
      setAppliedDiscountCode(trimmed);
      showToast(`Promo applied`, `Saved code ${trimmed}`);
      return { success: true, message: 'Discount successfully applied to your bag!' };
    }
    return { success: false, message: 'Invalid or expired promo code. Check your Glow Club rewards.' };
  };

  const removeDiscountCode = () => {
    setAppliedDiscountCode(null);
  };

  const addLoyaltyPoints = (amount: number) => {
    setLoyaltyPoints(prev => prev + amount);
  };

  const claimDailyCheckIn = () => {
    if (hasCheckedInToday) {
      return { success: false, pointsEarned: 0 };
    }
    const bonus = 25;
    setLoyaltyPoints(prev => prev + bonus);
    setDailyStreak(prev => prev + 1);
    setHasCheckedInToday(true);
    showToast(`+25 Glow Points Earned!`, `Daily streak: ${dailyStreak + 1} days!`);
    return { success: true, pointsEarned: bonus };
  };

  const redeemReward = (rewardId: string) => {
    const reward = LOYALTY_REWARDS.find(r => r.id === rewardId);
    if (!reward) return { success: false, message: 'Reward not found' };
    if (loyaltyPoints < reward.pointsCost) {
      return { success: false, message: 'Insufficient Glow points for this reward' };
    }
    setLoyaltyPoints(prev => prev - reward.pointsCost);
    setRedeemedRewards(prev => [...prev, rewardId]);
    setAppliedDiscountCode(reward.discountCode);
    showToast(`Reward Redeemed!`, `Applied ${reward.discountCode} to your bag`);
    return { success: true, message: `Redeemed ${reward.title}. Promo ${reward.discountCode} ready in checkout!` };
  };

  const advanceOrderSimulation = (orderId: string) => {
    setOrders(prev =>
      prev.map(ord => {
        if (ord.id !== orderId) return ord;
        const nextIndex = Math.min(ord.steps.length - 1, ord.currentStepIndex + 1);
        const updatedSteps = ord.steps.map((st, idx) => ({
          ...st,
          completed: idx <= nextIndex,
          active: idx === nextIndex
        }));
        const newProgress = Math.min(100, ord.courierGps.progressPercent + 15);
        const updatedOrder = {
          ...ord,
          currentStepIndex: nextIndex,
          steps: updatedSteps,
          courierGps: { ...ord.courierGps, progressPercent: newProgress }
        };
        if (activeTrackingOrder?.id === orderId) {
          setActiveTrackingOrder(updatedOrder);
        }
        return updatedOrder;
      })
    );
    showToast(`Shipment Update`, `Order status advanced to ${orders.find(o => o.id === orderId)?.steps[Math.min(orders.find(o => o.id === orderId)!.steps.length - 1, orders.find(o => o.id === orderId)!.currentStepIndex + 1)]?.status}`);
  };

  const unreadNotificationCount = notifications.filter(n => n.unread).length;

  const markNotificationsAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, unread: false })));
  };

  const togglePushNotifications = () => {
    const nextState = !pushNotificationsEnabled;
    setPushNotificationsEnabled(nextState);
    if (nextState) {
      showToast(`Push Notifications Active`, `You will receive drop alerts & tracking updates`);
    } else {
      showToast(`Push Notifications Paused`);
    }
  };

  const triggerPushNotification = (title: string, message: string, type: 'arrival' | 'drop' | 'order' | 'loyalty', actionUrl?: string) => {
    const newNotif: NotificationItem = {
      id: `notif-${Date.now()}`,
      title,
      message,
      timestamp: 'Just now',
      type,
      unread: true,
      actionUrl
    };
    setNotifications(prev => [newNotif, ...prev]);
    if (pushNotificationsEnabled) {
      showToast(title, message);
    }
  };

  const createOrder = (details: CheckoutDetails): Order => {
    const newOrderNumber = `AUR-${Math.floor(100000 + Math.random() * 900000)}`;
    const newTrackingNumber = `AUR-EXP-${Math.floor(10000000 + Math.random() * 90000000)}`;

    const newOrder: Order = {
      id: `ord-${Date.now()}`,
      orderNumber: newOrderNumber,
      createdAt: 'Just now',
      items: [...cart],
      subtotal: cartSubtotal,
      discount: cartDiscount,
      shipping: cartShipping,
      total: cartTotal,
      paymentMethod: details.paymentMethod,
      shippingAddress: {
        fullName: details.fullName,
        street: details.street,
        city: details.city,
        state: details.state,
        zip: details.zip
      },
      trackingNumber: newTrackingNumber,
      carrier: 'BlueDart Express Climate-Neutral Air',
      estimatedDelivery: '2 business days',
      currentStepIndex: 0,
      courierGps: {
        lat: 19.0760,
        lng: 72.8777,
        progressPercent: 5
      },
      steps: [
        {
          status: 'Order Placed',
          location: 'Mumbai Digital Atelier',
          timestamp: 'Just now',
          completed: true,
          active: true,
          note: `Payment via ${details.paymentMethod} verified`
        },
        {
          status: 'Cold-Pressed Batching',
          location: 'Aura Lab & Formulation Suite, Bengaluru',
          timestamp: 'Estimated in 2 hours',
          completed: false,
          active: false,
          note: 'Hand-blended fresh mineral shade allocation'
        },
        {
          status: 'Purity & QC Passed',
          location: 'Clean Cosmetic Cleanroom',
          timestamp: 'Estimated tomorrow',
          completed: false,
          active: false
        },
        {
          status: 'Dispatched',
          location: 'Express Logistics Hub',
          timestamp: 'Pending release',
          completed: false,
          active: false
        },
        {
          status: 'Out for Delivery',
          location: 'Local Courier Fleet',
          timestamp: 'Pending arrival',
          completed: false,
          active: false
        },
        {
          status: 'Delivered',
          location: `${details.city}, ${details.state}`,
          timestamp: 'Pending delivery',
          completed: false,
          active: false
        }
      ]
    };

    setOrders(prev => [newOrder, ...prev]);
    setActiveTrackingOrder(newOrder);
    setLoyaltyPoints(prev => prev + Math.floor(cartTotal * 1.25)); // Silver multiplier
    clearCart();
    setAppliedDiscountCode(null);
    setIsCheckoutOpen(false);

    triggerPushNotification(
      'Order Confirmed!',
      `Order #${newOrderNumber} is being prepared at our clean lab.`,
      'order',
      'loyalty-orders'
    );

    return newOrder;
  };

  return (
    <AppContext.Provider
      value={{
        currentPage,
        setCurrentPage,
        cart,
        addToCart,
        removeFromCart,
        updateQuantity,
        clearCart,
        cartSubtotal,
        cartDiscount,
        cartShipping,
        cartTotal,
        cartCount,
        isCartOpen,
        setIsCartOpen,
        appliedDiscountCode,
        applyDiscountCode,
        removeDiscountCode,
        loyaltyPoints,
        addLoyaltyPoints,
        dailyStreak,
        hasCheckedInToday,
        claimDailyCheckIn,
        redeemedRewards,
        redeemReward,
        orders,
        activeTrackingOrder,
        setActiveTrackingOrder,
        advanceOrderSimulation,
        notifications,
        unreadNotificationCount,
        markNotificationsAsRead,
        pushNotificationsEnabled,
        togglePushNotifications,
        triggerPushNotification,
        userSkinProfile,
        setUserSkinProfile,
        quickViewProduct,
        setQuickViewProduct,
        isCheckoutOpen,
        setIsCheckoutOpen,
        isShadeMixerOpen,
        setIsShadeMixerOpen,
        selectedIngredientForModal,
        setSelectedIngredientForModal,
        isSoundEnabled,
        toggleSound,
        createOrder,
        toastMessage,
        dismissToast
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
