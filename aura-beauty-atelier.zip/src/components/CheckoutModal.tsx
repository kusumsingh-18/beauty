import React, { useState } from 'react';
import { X, Lock, CreditCard, ShieldCheck, CheckCircle2, Loader2, ArrowRight, Smartphone, Building, Banknote } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { sound } from '../utils/audio';

export const CheckoutModal: React.FC = () => {
  const {
    isCheckoutOpen,
    setIsCheckoutOpen,
    cart,
    cartSubtotal,
    cartDiscount,
    cartShipping,
    cartTotal,
    createOrder,
    setCurrentPage
  } = useApp();

  const [paymentMethod, setPaymentMethod] = useState<'upi' | 'card' | 'netbanking' | 'cod'>('upi');
  const [upiId, setUpiId] = useState('aanya@okhdfcbank');
  const [selectedBank, setSelectedBank] = useState('HDFC Bank');
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStep, setProcessingStep] = useState<string>('');

  const [formData, setFormData] = useState({
    fullName: 'Aanya Sharma',
    email: 'aanya.sharma@atelier.in',
    street: '402 Regency Towers, Pali Hill, Bandra West',
    city: 'Mumbai',
    state: 'Maharashtra',
    zip: '400050',
    cardNumber: '5242 •••• •••• 8821',
    cardExp: '08/29',
    cardCvv: '482'
  });

  if (!isCheckoutOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    sound.playClick();
    setIsProcessing(true);
    setProcessingStep('Connecting to NPCI / Unified Payments Interface gateway...');

    setTimeout(() => {
      setProcessingStep(
        paymentMethod === 'upi'
          ? 'Authorizing UPI handle with issuing bank...'
          : paymentMethod === 'cod'
          ? 'Generating OTP verification & order reservation...'
          : 'Encrypting 256-bit token with Reserve Bank of India 2FA...'
      );
      setTimeout(() => {
        setProcessingStep('Allocating fresh micro-batch at clean formulation cleanroom...');
        setTimeout(() => {
          sound.playChime();
          const methodLabel =
            paymentMethod === 'upi'
              ? `UPI (${upiId} - Instant Authorized)`
              : paymentMethod === 'card'
              ? 'RuPay / Visa ending in 8821 (3D Secure)'
              : paymentMethod === 'netbanking'
              ? `${selectedBank} NetBanking (Authorized)`
              : 'Cash on Delivery (Verified via Mobile OTP)';

          createOrder({
            fullName: formData.fullName,
            email: formData.email,
            street: formData.street,
            city: formData.city,
            state: formData.state,
            zip: formData.zip,
            paymentMethod: methodLabel,
            cardNumber: formData.cardNumber
          });

          setIsProcessing(false);
          setIsCheckoutOpen(false);
          setCurrentPage('loyalty-orders');
        }, 800);
      }, 800);
    }, 900);
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6">
      {/* Backdrop */}
      <div
        onClick={() => !isProcessing && setIsCheckoutOpen(false)}
        className="fixed inset-0 bg-stone-900/60 backdrop-blur-xs transition-opacity"
      />

      <div className="relative bg-[#FAF9F5] border border-stone-300 w-full max-w-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-stone-200 bg-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-stone-100 border border-stone-200 text-stone-800">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-sm font-semibold tracking-widest uppercase text-stone-900">
                Aura Secure Indian Checkout
              </h2>
              <p className="text-xs text-stone-500 font-mono">
                RBI Compliant 256-Bit Tokenized Payment Gateway
              </p>
            </div>
          </div>
          {!isProcessing && (
            <button
              onClick={() => setIsCheckoutOpen(false)}
              className="text-stone-400 hover:text-stone-700 p-1 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>

        {isProcessing ? (
          <div className="p-12 text-center space-y-4">
            <Loader2 className="w-8 h-8 text-stone-900 animate-spin mx-auto" />
            <h3 className="text-sm uppercase tracking-widest font-semibold text-stone-900">
              Authorizing Secure Payment
            </h3>
            <p className="text-xs text-stone-500 font-mono">{processingStep}</p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="p-6 sm:p-8 space-y-6">
            {/* Express Gateways */}
            <div>
              <label className="block text-[11px] uppercase tracking-widest font-semibold text-stone-600 mb-3">
                Select Payment Mode (INR ₹)
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setPaymentMethod('upi');
                  }}
                  className={`p-3 text-xs border font-medium transition-all text-center flex flex-col items-center justify-center gap-1 cursor-pointer ${
                    paymentMethod === 'upi'
                      ? 'border-stone-900 bg-white text-stone-900 shadow-xs ring-1 ring-stone-900'
                      : 'border-stone-200 bg-stone-50 text-stone-600 hover:bg-white'
                  }`}
                >
                  <Smartphone className="w-4 h-4 text-emerald-700" />
                  <span className="font-semibold">UPI / QR</span>
                  <span className="text-[10px] text-stone-400">GPay/PhonePe</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setPaymentMethod('card');
                  }}
                  className={`p-3 text-xs border font-medium transition-all text-center flex flex-col items-center justify-center gap-1 cursor-pointer ${
                    paymentMethod === 'card'
                      ? 'border-stone-900 bg-white text-stone-900 shadow-xs ring-1 ring-stone-900'
                      : 'border-stone-200 bg-stone-50 text-stone-600 hover:bg-white'
                  }`}
                >
                  <CreditCard className="w-4 h-4" />
                  <span className="font-semibold">RuPay / Card</span>
                  <span className="text-[10px] text-stone-400">Debit / Credit</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setPaymentMethod('netbanking');
                  }}
                  className={`p-3 text-xs border font-medium transition-all text-center flex flex-col items-center justify-center gap-1 cursor-pointer ${
                    paymentMethod === 'netbanking'
                      ? 'border-stone-900 bg-white text-stone-900 shadow-xs ring-1 ring-stone-900'
                      : 'border-stone-200 bg-stone-50 text-stone-600 hover:bg-white'
                  }`}
                >
                  <Building className="w-4 h-4 text-cyan-800" />
                  <span className="font-semibold">NetBanking</span>
                  <span className="text-[10px] text-stone-400">All Indian Banks</span>
                </button>

                <button
                  type="button"
                  onClick={() => {
                    sound.playClick();
                    setPaymentMethod('cod');
                  }}
                  className={`p-3 text-xs border font-medium transition-all text-center flex flex-col items-center justify-center gap-1 cursor-pointer ${
                    paymentMethod === 'cod'
                      ? 'border-stone-900 bg-white text-stone-900 shadow-xs ring-1 ring-stone-900'
                      : 'border-stone-200 bg-stone-50 text-stone-600 hover:bg-white'
                  }`}
                >
                  <Banknote className="w-4 h-4 text-amber-800" />
                  <span className="font-semibold">Cash On Delivery</span>
                  <span className="text-[10px] text-stone-400">Pay at Doorstep</span>
                </button>
              </div>
            </div>

            {/* UPI ID Field if UPI Selected */}
            {paymentMethod === 'upi' && (
              <div className="p-4 bg-emerald-50/50 border border-emerald-200 text-xs space-y-2">
                <span className="text-stone-700 font-semibold block">
                  Enter Your UPI Virtual Payment Address (VPA):
                </span>
                <div className="flex gap-2">
                  <input
                    type="text"
                    required
                    placeholder="e.g. mobile@upi or name@okhdfcbank"
                    value={upiId}
                    onChange={e => setUpiId(e.target.value)}
                    className="flex-1 px-3 py-2 text-xs border border-stone-300 bg-white font-mono focus:outline-none focus:border-stone-900"
                  />
                  <span className="px-3 py-2 bg-emerald-100 text-emerald-900 text-[11px] font-semibold flex items-center">
                    Instant 0% Fee
                  </span>
                </div>
                <p className="text-[11px] text-stone-500">
                  A payment authorization request will be dispatched directly to your UPI app.
                </p>
              </div>
            )}

            {/* NetBanking Bank Selector if NetBanking selected */}
            {paymentMethod === 'netbanking' && (
              <div className="p-4 bg-stone-50 border border-stone-200 text-xs space-y-2">
                <span className="text-stone-700 font-semibold block">Select Your Bank:</span>
                <select
                  value={selectedBank}
                  onChange={e => setSelectedBank(e.target.value)}
                  className="w-full px-3 py-2 text-xs border border-stone-300 bg-white focus:outline-none focus:border-stone-900"
                >
                  <option value="HDFC Bank">HDFC Bank</option>
                  <option value="ICICI Bank">ICICI Bank</option>
                  <option value="State Bank of India">State Bank of India (SBI)</option>
                  <option value="Axis Bank">Axis Bank</option>
                  <option value="Kotak Mahindra Bank">Kotak Mahindra Bank</option>
                </select>
              </div>
            )}

            {/* Delivery Details */}
            <div className="space-y-3">
              <label className="block text-[11px] uppercase tracking-widest font-semibold text-stone-600">
                1. Delivery & Recipient Details (India)
              </label>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <span className="text-[11px] text-stone-500 block mb-1">Full Legal Name</span>
                  <input
                    required
                    type="text"
                    value={formData.fullName}
                    onChange={e => setFormData({ ...formData, fullName: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>
                <div>
                  <span className="text-[11px] text-stone-500 block mb-1">Email For BlueDart Tracking</span>
                  <input
                    required
                    type="email"
                    value={formData.email}
                    onChange={e => setFormData({ ...formData, email: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>
              </div>

              <div>
                <span className="text-[11px] text-stone-500 block mb-1">Street Address & Landmark</span>
                <input
                  required
                  type="text"
                  value={formData.street}
                  onChange={e => setFormData({ ...formData, street: e.target.value })}
                  className="w-full px-3 py-2 text-xs border border-stone-300 bg-white focus:outline-none focus:border-stone-900"
                />
              </div>

              <div className="grid grid-cols-3 gap-3">
                <div>
                  <span className="text-[11px] text-stone-500 block mb-1">City</span>
                  <input
                    required
                    type="text"
                    value={formData.city}
                    onChange={e => setFormData({ ...formData, city: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>
                <div>
                  <span className="text-[11px] text-stone-500 block mb-1">State</span>
                  <input
                    required
                    type="text"
                    value={formData.state}
                    onChange={e => setFormData({ ...formData, state: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 bg-white focus:outline-none focus:border-stone-900"
                  />
                </div>
                <div>
                  <span className="text-[11px] text-stone-500 block mb-1">PIN Code</span>
                  <input
                    required
                    type="text"
                    maxLength={6}
                    value={formData.zip}
                    onChange={e => setFormData({ ...formData, zip: e.target.value })}
                    className="w-full px-3 py-2 text-xs border border-stone-300 bg-white focus:outline-none focus:border-stone-900 font-mono"
                  />
                </div>
              </div>
            </div>

            {/* Card Information if Card Selected */}
            {paymentMethod === 'card' && (
              <div className="space-y-3 pt-2 border-t border-stone-200">
                <label className="block text-[11px] uppercase tracking-widest font-semibold text-stone-600">
                  2. RuPay / Card Details
                </label>
                <div>
                  <span className="text-[11px] text-stone-500 block mb-1">Card Number</span>
                  <div className="relative">
                    <input
                      required
                      type="text"
                      value={formData.cardNumber}
                      onChange={e => setFormData({ ...formData, cardNumber: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-stone-300 bg-white focus:outline-none focus:border-stone-900 font-mono"
                    />
                    <CreditCard className="w-4 h-4 text-stone-400 absolute right-3 top-2.5" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <span className="text-[11px] text-stone-500 block mb-1">Valid Thru (MM/YY)</span>
                    <input
                      required
                      type="text"
                      value={formData.cardExp}
                      onChange={e => setFormData({ ...formData, cardExp: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-stone-300 bg-white focus:outline-none focus:border-stone-900 font-mono"
                    />
                  </div>
                  <div>
                    <span className="text-[11px] text-stone-500 block mb-1">CVV Code</span>
                    <input
                      required
                      type="password"
                      maxLength={4}
                      value={formData.cardCvv}
                      onChange={e => setFormData({ ...formData, cardCvv: e.target.value })}
                      className="w-full px-3 py-2 text-xs border border-stone-300 bg-white focus:outline-none focus:border-stone-900 font-mono"
                    />
                  </div>
                </div>
              </div>
            )}

            {/* Order Summary Recap in INR */}
            <div className="bg-white p-4 border border-stone-200 space-y-2 text-xs">
              <div className="flex justify-between text-stone-600">
                <span>Items Subtotal ({cart.length})</span>
                <span className="tabular-nums font-mono">₹{cartSubtotal}</span>
              </div>
              {cartDiscount > 0 && (
                <div className="flex justify-between text-emerald-800">
                  <span>Promo / Glow Discount</span>
                  <span className="tabular-nums font-mono">-₹{cartDiscount}</span>
                </div>
              )}
              <div className="flex justify-between text-stone-600">
                <span>BlueDart Climate-Neutral Express</span>
                <span className="tabular-nums font-mono">
                  {cartShipping === 0 ? 'Complimentary' : `₹${cartShipping}`}
                </span>
              </div>
              <div className="flex justify-between text-sm font-semibold text-stone-900 pt-2 border-t border-stone-200">
                <span>Total Payable Now</span>
                <span className="tabular-nums font-mono">₹{cartTotal}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="space-y-3">
              <button
                type="submit"
                className="w-full py-3.5 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Authorize & Place Order (₹{cartTotal})</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-stone-500">
                <ShieldCheck className="w-3.5 h-3.5 text-stone-700" />
                <span>100% RBI & PCI-DSS Compliant · Live Courier Tracking Provided</span>
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
