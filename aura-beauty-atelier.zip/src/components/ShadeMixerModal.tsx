import React, { useState, useEffect, useRef } from 'react';
import { X, Sparkles, Sliders, Droplets, ArrowRight, Check, RefreshCw } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PRODUCTS } from '../data/products';
import { Shade } from '../types';
import { sound } from '../utils/audio';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

// Color interpolation
function interpolateHex(hex1: string, hex2: string, ratio: number): string {
  const r1 = parseInt(hex1.slice(1, 3), 16);
  const g1 = parseInt(hex1.slice(3, 5), 16);
  const b1 = parseInt(hex1.slice(5, 7), 16);

  const r2 = parseInt(hex2.slice(1, 3), 16);
  const g2 = parseInt(hex2.slice(3, 5), 16);
  const b2 = parseInt(hex2.slice(5, 7), 16);

  const r = Math.round(r1 + (r2 - r1) * ratio);
  const g = Math.round(g1 + (g2 - g1) * ratio);
  const b = Math.round(b1 + (b2 - b1) * ratio);

  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

export const ShadeMixerModal: React.FC<Props> = ({ isOpen, onClose }) => {
  const { addToCart, setCurrentPage } = useApp();
  const lipProduct = PRODUCTS[0]; // Suede Rouge

  const [shadeA, setShadeA] = useState<Shade>(lipProduct.shades[0]);
  const [shadeB, setShadeB] = useState<Shade>(lipProduct.shades[1]);
  const [mixRatio, setMixRatio] = useState<number>(50); // 0 to 100%
  const [customName, setCustomName] = useState<string>('Custom Atelier Hybrid');

  const canvasRef = useRef<HTMLCanvasElement>(null);

  const blendedHex = interpolateHex(shadeA.hex, shadeB.hex, mixRatio / 100);

  // Draw dynamic paint swirls on cosmetic plate
  useEffect(() => {
    if (!isOpen) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;

    // Clear with soft glass background
    ctx.clearRect(0, 0, width, height);

    // Draw marble mixing droplet effect
    const grad = ctx.createLinearGradient(0, 0, width, height);
    grad.addColorStop(0, shadeA.hex);
    grad.addColorStop(mixRatio / 100, blendedHex);
    grad.addColorStop(1, shadeB.hex);

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.ellipse(width / 2, height / 2, width * 0.42, height * 0.38, 0, 0, Math.PI * 2);
    ctx.fill();

    // Swirl accents
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(width / 2 - 10, height / 2 - 5, 35, 0.2, Math.PI * 1.3);
    ctx.stroke();

    ctx.strokeStyle = 'rgba(0, 0, 0, 0.15)';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(width / 2 + 15, height / 2 + 10, 45, 0.8, Math.PI * 1.8);
    ctx.stroke();
  }, [isOpen, shadeA, shadeB, mixRatio, blendedHex]);

  if (!isOpen) return null;

  const handleApplyToTryOn = () => {
    sound.playChime();
    onClose();
    setCurrentPage('tryon');
  };

  const handleAddToCart = () => {
    sound.playChime();
    const customShade: Shade = {
      id: `mix-${Date.now()}`,
      name: `${customName} (${100 - mixRatio}% ${shadeA.name} / ${mixRatio}% ${shadeB.name})`,
      hex: blendedHex,
      finish: 'Velvet Matte'
    };
    addToCart(lipProduct, customShade, 1);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6">
      <div
        onClick={onClose}
        className="fixed inset-0 bg-stone-950/60 backdrop-blur-xs transition-opacity"
      />

      <div className="relative bg-[#FAF9F5] border border-stone-300 w-full max-w-2xl shadow-2xl overflow-hidden my-8">
        {/* Header */}
        <div className="p-6 border-b border-stone-200 bg-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-stone-100 text-stone-900 border border-stone-200">
              <Sparkles className="w-4 h-4 text-amber-700" />
            </div>
            <div>
              <h2 className="text-sm font-semibold tracking-widest uppercase text-stone-900">
                Atelier Pigment Alchemy
              </h2>
              <p className="text-xs text-stone-500">
                Custom shade blending on virtual frosted glass palette
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-stone-400 hover:text-stone-700 p-1 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 sm:p-8 space-y-8">
          {/* Visual Swirl Plate */}
          <div className="flex flex-col items-center justify-center bg-stone-100 border border-stone-200 p-6">
            <canvas
              ref={canvasRef}
              width={340}
              height={180}
              className="max-w-full drop-shadow-md rounded-xl"
            />
            <div className="flex items-center gap-3 mt-4 text-xs">
              <span
                className="w-4 h-4 rounded-full border border-stone-300"
                style={{ backgroundColor: blendedHex }}
              />
              <span className="font-mono font-semibold text-stone-900 tabular-nums">
                {blendedHex.toUpperCase()}
              </span>
              <span className="text-stone-400">·</span>
              <span className="text-stone-600">
                {100 - mixRatio}% {shadeA.name} / {mixRatio}% {shadeB.name}
              </span>
            </div>
          </div>

          {/* Interactive Blend Slider */}
          <div className="space-y-3">
            <div className="flex justify-between items-center text-xs">
              <span className="text-stone-600 font-medium">1. Blend Ratio</span>
              <span className="font-mono text-stone-900 tabular-nums">
                {100 - mixRatio}% : {mixRatio}%
              </span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={mixRatio}
              onChange={e => {
                setMixRatio(Number(e.target.value));
                sound.playClick();
              }}
              className="w-full accent-stone-900 cursor-pointer"
            />
          </div>

          {/* Choose Shade A & Shade B */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2 border-t border-stone-200">
            {/* Shade A Selector */}
            <div className="space-y-2">
              <span className="text-xs uppercase tracking-wider font-semibold text-stone-700 block">
                Primary Base ({100 - mixRatio}%)
              </span>
              <div className="grid grid-cols-3 gap-2">
                {lipProduct.shades.map(s => (
                  <button
                    key={s.id}
                    onClick={() => {
                      setShadeA(s);
                      sound.playClick();
                    }}
                    className={`p-2 border text-center text-xs transition-all cursor-pointer ${
                      shadeA.id === s.id
                        ? 'border-stone-900 bg-white ring-1 ring-stone-900'
                        : 'border-stone-200 bg-stone-50 hover:bg-white'
                    }`}
                  >
                    <span
                      className="w-4 h-4 rounded-full border mx-auto block mb-1"
                      style={{ backgroundColor: s.hex }}
                    />
                    <p className="truncate text-[10px] text-stone-800">{s.name}</p>
                  </button>
                ))}
              </div>
            </div>

            {/* Shade B Selector */}
            <div className="space-y-2">
              <span className="text-xs uppercase tracking-wider font-semibold text-stone-700 block">
                Secondary Infusion ({mixRatio}%)
              </span>
              <div className="grid grid-cols-3 gap-2">
                {lipProduct.shades.map(s => (
                  <button
                    key={s.id}
                    onClick={() => {
                      setShadeB(s);
                      sound.playClick();
                    }}
                    className={`p-2 border text-center text-xs transition-all cursor-pointer ${
                      shadeB.id === s.id
                        ? 'border-stone-900 bg-white ring-1 ring-stone-900'
                        : 'border-stone-200 bg-stone-50 hover:bg-white'
                    }`}
                  >
                    <span
                      className="w-4 h-4 rounded-full border mx-auto block mb-1"
                      style={{ backgroundColor: s.hex }}
                    />
                    <p className="truncate text-[10px] text-stone-800">{s.name}</p>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Naming input */}
          <div className="space-y-1.5 pt-2 border-t border-stone-200">
            <label className="text-xs uppercase tracking-wider font-semibold text-stone-700 block">
              Name Your Custom Formula
            </label>
            <input
              type="text"
              value={customName}
              onChange={e => setCustomName(e.target.value)}
              className="w-full px-3 py-2 text-xs border border-stone-300 bg-white focus:outline-none focus:border-stone-900"
            />
          </div>

          {/* Action CTAs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-4 border-t border-stone-200">
            <button
              onClick={handleAddToCart}
              className="py-3 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Add Custom Blend to Bag (₹{lipProduct.price.toLocaleString('en-IN')})</span>
            </button>

            <button
              onClick={handleApplyToTryOn}
              className="py-3 bg-white border border-stone-300 text-stone-900 text-xs uppercase tracking-widest font-medium hover:bg-stone-50 transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <Sparkles className="w-4 h-4 text-amber-700" />
              <span>Launch in Virtual Studio</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
