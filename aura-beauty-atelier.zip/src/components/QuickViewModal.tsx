import React, { useState } from 'react';
import { X, Star, Sparkles, Check, ArrowRight, ShieldCheck, Heart } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { Shade } from '../types';

export const QuickViewModal: React.FC = () => {
  const { quickViewProduct, setQuickViewProduct, addToCart, setCurrentPage } = useApp();
  const [selectedShade, setSelectedShade] = useState<Shade | null>(null);

  if (!quickViewProduct) return null;

  const currentShade = selectedShade || quickViewProduct.shades[0];

  const handleAddToCart = () => {
    addToCart(quickViewProduct, currentShade, 1);
    setQuickViewProduct(null);
  };

  const handleGoToTryOn = () => {
    setQuickViewProduct(null);
    setCurrentPage('tryon');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 sm:p-6">
      <div
        onClick={() => setQuickViewProduct(null)}
        className="fixed inset-0 bg-stone-900/50 backdrop-blur-xs transition-opacity"
      />

      <div className="relative bg-[#FAF9F5] border border-stone-200 w-full max-w-3xl shadow-2xl overflow-hidden my-8">
        <button
          onClick={() => setQuickViewProduct(null)}
          className="absolute top-4 right-4 z-10 p-2 text-stone-500 hover:text-stone-900 bg-white/80 rounded-full transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2">
          {/* Product Image */}
          <div className="bg-stone-100 p-8 flex items-center justify-center border-b md:border-b-0 md:border-r border-stone-200">
            <img
              src={quickViewProduct.image}
              alt={quickViewProduct.name}
              className="max-h-80 w-auto object-contain transition-transform duration-300 hover:scale-105"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Details */}
          <div className="p-6 sm:p-8 flex flex-col justify-between">
            <div className="space-y-4">
              <div>
                <div className="flex items-center gap-2 text-xs text-stone-500 mb-1">
                  <span>{quickViewProduct.category}</span>
                  <span aria-hidden="true">·</span>
                  <div className="flex items-center text-amber-800">
                    <Star className="w-3 h-3 fill-amber-700 stroke-amber-700" />
                    <span className="ml-1 font-mono tabular-nums text-stone-800">{quickViewProduct.rating}</span>
                    <span className="text-stone-400 ml-1">({quickViewProduct.reviewCount})</span>
                  </div>
                </div>

                <h2 className="text-xl font-editorial font-semibold text-stone-900 leading-snug">
                  {quickViewProduct.name}
                </h2>
                <p className="text-xs text-stone-500 mt-1">{quickViewProduct.subtitle}</p>

                <p className="text-lg font-mono text-stone-900 font-medium tabular-nums mt-2">
                  ₹{quickViewProduct.price.toLocaleString('en-IN')}
                </p>
              </div>

              {/* Shade Selector */}
              <div>
                <div className="flex justify-between items-center text-xs mb-2">
                  <span className="text-stone-600">Selected Shade:</span>
                  <strong className="text-stone-900">{currentShade.name}</strong>
                </div>

                <div className="flex flex-wrap gap-2">
                  {quickViewProduct.shades.map(sh => {
                    const isSelected = currentShade.id === sh.id;
                    return (
                      <button
                        key={sh.id}
                        type="button"
                        onClick={() => setSelectedShade(sh)}
                        className={`w-7 h-7 rounded-full border-2 transition-transform cursor-pointer relative ${
                          isSelected ? 'border-stone-900 scale-110' : 'border-stone-300 hover:border-stone-500'
                        }`}
                        style={{ backgroundColor: sh.hex }}
                        title={`${sh.name} - ${sh.finish}`}
                      >
                        {isSelected && (
                          <span className="absolute inset-0 flex items-center justify-center text-white drop-shadow-xs">
                            <Check className="w-3 h-3 stroke-[3]" />
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>
                <div className="text-[11px] text-stone-500 mt-1.5 flex items-center gap-1.5">
                  <span>Finish: {currentShade.finish}</span>
                </div>
              </div>

              {/* Key Bio-Actives */}
              <div className="pt-2 border-t border-stone-200">
                <span className="text-[11px] uppercase tracking-wider font-semibold text-stone-800 block mb-1.5">
                  Clean Active Ingredients:
                </span>
                <div className="space-y-1">
                  {quickViewProduct.ingredients.slice(0, 3).map((ing, i) => (
                    <div key={i} className="text-xs text-stone-600 flex items-baseline gap-1.5">
                      <span className="w-1.5 h-1.5 rounded-full bg-stone-400 shrink-0" />
                      <span>
                        <strong className="text-stone-800">{ing.name}</strong>: {ing.benefit}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="space-y-2.5 pt-6 mt-6 border-t border-stone-200">
              <button
                onClick={handleAddToCart}
                className="w-full py-3 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Add To Bag · ₹{quickViewProduct.price.toLocaleString('en-IN')}</span>
              </button>

              <button
                onClick={handleGoToTryOn}
                className="w-full py-2.5 bg-stone-100 border border-stone-300 text-stone-800 text-xs uppercase tracking-widest font-medium hover:bg-stone-200 transition-colors flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-3.5 h-3.5 text-stone-700" />
                <span>Test in Virtual Studio</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
