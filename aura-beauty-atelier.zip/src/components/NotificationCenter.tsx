import React, { useRef, useEffect } from 'react';
import { Bell, Check, BellRing, Sparkles, Package, Gift, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationCenter: React.FC<Props> = ({ isOpen, onClose }) => {
  const {
    notifications,
    markNotificationsAsRead,
    pushNotificationsEnabled,
    togglePushNotifications,
    triggerPushNotification,
    setCurrentPage,
    setActiveTrackingOrder,
    orders
  } = useApp();

  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        onClose();
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const handleSimulateNewDrop = () => {
    triggerPushNotification(
      'Exclusive Drop Alert',
      'Atelier Mineral Cashmere Eye Quad in "Earth & Alabaster" is back in limited stock.',
      'arrival',
      'shop'
    );
  };

  const handleActionClick = (url?: string) => {
    if (url === 'shop') {
      setCurrentPage('shop');
    } else if (url === 'loyalty-orders') {
      setCurrentPage('loyalty-orders');
      if (orders.length > 0) {
        setActiveTrackingOrder(orders[0]);
      }
    }
    onClose();
  };

  return (
    <div
      ref={ref}
      className="absolute right-0 top-full mt-3 w-80 sm:w-96 bg-white border border-stone-200 shadow-xl rounded-none z-50 overflow-hidden"
    >
      {/* Header */}
      <div className="p-4 border-b border-stone-200 flex items-center justify-between bg-[#FAF9F5]">
        <div className="flex items-center gap-2">
          <Bell className="w-4 h-4 text-stone-800" />
          <span className="text-xs uppercase tracking-widest font-semibold text-stone-900">
            Atelier Alerts
          </span>
        </div>
        <div className="flex items-center gap-3">
          <button
            onClick={markNotificationsAsRead}
            className="text-[11px] text-stone-500 hover:text-stone-900 transition-colors"
          >
            Mark all read
          </button>
          <button onClick={onClose} className="text-stone-400 hover:text-stone-700">
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Push toggle */}
      <div className="px-4 py-3 bg-stone-50 border-b border-stone-200 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2">
          <BellRing className={`w-3.5 h-3.5 ${pushNotificationsEnabled ? 'text-amber-800' : 'text-stone-400'}`} />
          <span className="text-stone-700">Browser Push Alerts</span>
        </div>
        <button
          onClick={togglePushNotifications}
          className={`px-2.5 py-1 text-[11px] uppercase tracking-wider font-medium transition-colors ${
            pushNotificationsEnabled
              ? 'bg-stone-900 text-white'
              : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
          }`}
        >
          {pushNotificationsEnabled ? 'Active' : 'Disabled'}
        </button>
      </div>

      {/* Notifications list */}
      <div className="max-h-80 overflow-y-auto divide-y divide-stone-100">
        {notifications.length === 0 ? (
          <div className="p-6 text-center text-xs text-stone-400">
            No active notifications
          </div>
        ) : (
          notifications.map(item => (
            <div
              key={item.id}
              className={`p-3.5 transition-colors cursor-pointer hover:bg-stone-50 ${
                item.unread ? 'bg-[#FCFBF8]' : ''
              }`}
              onClick={() => handleActionClick(item.actionUrl)}
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5 shrink-0">
                  {item.type === 'arrival' && <Sparkles className="w-3.5 h-3.5 text-stone-800" />}
                  {item.type === 'order' && <Package className="w-3.5 h-3.5 text-stone-700" />}
                  {item.type === 'loyalty' && <Gift className="w-3.5 h-3.5 text-amber-700" />}
                  {item.type === 'drop' && <Sparkles className="w-3.5 h-3.5 text-rose-800" />}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-semibold text-stone-900">{item.title}</h4>
                    <span className="text-[10px] text-stone-400 tabular-nums">{item.timestamp}</span>
                  </div>
                  <p className="text-xs text-stone-600 mt-0.5 leading-relaxed">{item.message}</p>
                </div>
                {item.unread && (
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-800 shrink-0 mt-1" />
                )}
              </div>
            </div>
          ))
        )}
      </div>

      {/* Simulator footer action */}
      <div className="p-3 border-t border-stone-200 bg-[#FAF9F5] flex items-center justify-between">
        <span className="text-[11px] text-stone-500">Test Real-Time Alert</span>
        <button
          onClick={handleSimulateNewDrop}
          className="text-xs font-medium text-stone-900 hover:underline inline-flex items-center gap-1"
        >
          <Sparkles className="w-3 h-3" /> Simulate Drop
        </button>
      </div>
    </div>
  );
};
