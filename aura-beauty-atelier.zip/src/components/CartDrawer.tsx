import React, { useState } from 'react';
import { X, Minus, Plus, Trash2, ShieldCheck, ArrowRight, Sparkles } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const CartDrawer: React.FC = () => {
  const {
    isCartOpen,
    setIsCartOpen,
    cart,
    removeFromCart,
    updateQuantity,
    cartSubtotal,
    cartDiscount,
    cartShipping,
    cartTotal,
    appliedDiscountCode,
    applyDiscountCode,
    removeDiscountCode,
    setIsCheckoutOpen,
    setCurrentPage,
    setSelectedIngredientForModal
  } = useApp();

  const [promoInput, setPromoInput] = useState('');
  const [promoFeedback, setPromoFeedback] = useState<{ text: string; error: boolean } | null>(null);

  if (!isCartOpen) return null;

  // Multi-tier reward milestone progress
  const freeShippingThreshold = 1999;
  const silkPouchThreshold = 3499;
  const miniSerumThreshold = 4999;

  const hasFreeShipping = cartSubtotal >= freeShippingThreshold;
  const hasSilkPouch = cartSubtotal >= silkPouchThreshold;
  const hasMiniSerum = cartSubtotal >= miniSerumThreshold;

  const progressPercent = Math.min(100, (cartSubtotal / miniSerumThreshold) * 100);

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoInput.trim()) return;
    const res = applyDiscountCode(promoInput);
    setPromoFeedback({ text: res.message, error: !res.success });
    if (res.success) {
      setPromoInput('');
    }
  };

  const handleStartCheckout = () => {
    setIsCartOpen(false);
    setIsCheckoutOpen(true);
  };

  const handleBrowseShop = () => {
    setIsCartOpen(false);
    setCurrentPage('shop');
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        onClick={() => setIsCartOpen(false)}
        className="absolute inset-0 bg-stone-900/40 backdrop-blur-xs transition-opacity"
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#FAF9F5] border-l border-stone-200 shadow-2xl flex flex-col">
          {/* Drawer Header */}
          <div className="p-6 border-b border-stone-200 flex items-center justify-between bg-white">
            <div>
              <h2 className="text-sm font-semibold tracking-widest uppercase text-stone-900">
                Your Atelier Bag
              </h2>
              <p className="text-xs text-stone-500 mt-0.5">
                {cart.length} {cart.length === 1 ? 'item' : 'items'} curated
              </p>
            </div>
            <button
              onClick={() => setIsCartOpen(false)}
              className="p-1.5 text-stone-400 hover:text-stone-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Complimentary Tier Milestones */}
          <div className="px-6 py-3.5 bg-[#F4F2EC] border-b border-stone-200 text-xs text-stone-700 space-y-2">
            <div className="flex justify-between items-center text-[11px]">
              <span className="font-semibold text-stone-900 uppercase tracking-wider">
                Atelier Tier Gifts
              </span>
              <span className="font-mono tabular-nums text-stone-600">
                ₹{cartSubtotal} / ₹4,999
              </span>
            </div>

            <div className="w-full bg-stone-300 h-1.5 rounded-none overflow-hidden relative">
              <div
                className="bg-stone-900 h-full transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>

            <div className="grid grid-cols-3 text-[10px] text-stone-500 pt-0.5">
              <span className={hasFreeShipping ? 'font-semibold text-emerald-800' : ''}>
                ✓ ₹1,999 Ship
              </span>
              <span className={`text-center ${hasSilkPouch ? 'font-semibold text-emerald-800' : ''}`}>
                ✓ ₹3,499 Pouch
              </span>
              <span className={`text-right ${hasMiniSerum ? 'font-semibold text-emerald-800' : ''}`}>
                ✓ ₹4,999 Mini
              </span>
            </div>
          </div>

          {/* Items Scroll Area */}
          <div className="flex-1 overflow-y-auto p-6 space-y-6">
            {cart.length === 0 ? (
              <div className="text-center py-16 space-y-4">
                <p className="text-stone-400 text-sm">Your cosmetic bag is currently empty.</p>
                <button
                  onClick={handleBrowseShop}
                  className="px-6 py-2.5 bg-stone-900 text-white text-xs uppercase tracking-widest font-medium hover:bg-stone-800 transition-colors"
                >
                  Explore The Collection
                </button>
              </div>
            ) : (
              cart.map((item, idx) => (
                <div
                  key={`${item.product.id}-${item.selectedShade.id}-${idx}`}
                  className="flex gap-4 pb-6 border-b border-stone-200 last:border-0"
                >
                  <div className="w-20 h-20 bg-stone-100 shrink-0 overflow-hidden border border-stone-200">
                    <img
                      src={item.product.image}
                      alt={item.product.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="flex-1 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-start">
                        <h3 className="text-xs font-semibold text-stone-900 leading-snug">
                          {item.product.name}
                        </h3>
                        <span className="text-xs font-mono font-medium text-stone-900 tabular-nums ml-2">
                          ₹{item.product.price * item.quantity}
                        </span>
                      </div>
                      <div className="flex items-center gap-2 mt-1.5 text-xs text-stone-500">
                        <span
                          className="w-3 h-3 rounded-full border border-stone-300 shrink-0"
                          style={{ backgroundColor: item.selectedShade.hex }}
                        />
                        <span>{item.selectedShade.name}</span>
                        <span aria-hidden="true">·</span>
                        <span>{item.selectedShade.finish}</span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between mt-3 pt-2">
                      <div className="flex items-center border border-stone-300 bg-white">
                        <button
                          onClick={() => updateQuantity(item.product.id, item.selectedShade.id, item.quantity - 1)}
                          className="px-2 py-1 text-stone-600 hover:text-stone-900 hover:bg-stone-100"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="px-3 py-0.5 text-xs tabular-nums font-mono text-stone-900">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => updateQuantity(item.product.id, item.selectedShade.id, item.quantity + 1)}
                          className="px-2 py-1 text-stone-600 hover:text-stone-900 hover:bg-stone-100"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>

                      <button
                        onClick={() => removeFromCart(item.product.id, item.selectedShade.id)}
                        className="text-stone-400 hover:text-stone-700 transition-colors p-1"
                        aria-label="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          {/* Promo Code Input */}
          {cart.length > 0 && (
            <div className="px-6 py-3 border-t border-stone-200 bg-white">
              {appliedDiscountCode ? (
                <div className="flex items-center justify-between text-xs bg-stone-100 px-3 py-2 border border-stone-200">
                  <span className="text-stone-700">
                    Promo <strong>{appliedDiscountCode}</strong> applied (-₹{cartDiscount})
                  </span>
                  <button
                    onClick={removeDiscountCode}
                    className="text-xs text-stone-500 hover:text-stone-900 underline"
                  >
                    Remove
                  </button>
                </div>
              ) : (
                <form onSubmit={handleApplyPromo} className="space-y-1">
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Promo or Loyalty Code (e.g. GLOW500)"
                      value={promoInput}
                      onChange={e => setPromoInput(e.target.value)}
                      className="flex-1 px-3 py-2 text-xs border border-stone-300 focus:outline-none focus:border-stone-900 uppercase"
                    />
                    <button
                      type="submit"
                      className="px-3 py-2 bg-stone-200 text-stone-800 text-xs uppercase tracking-wider font-medium hover:bg-stone-300 cursor-pointer"
                    >
                      Apply
                    </button>
                  </div>
                  {promoFeedback && (
                    <p className={`text-[11px] ${promoFeedback.error ? 'text-rose-600' : 'text-emerald-700'}`}>
                      {promoFeedback.text}
                    </p>
                  )}
                </form>
              )}
            </div>
          )}

          {/* Financial Breakdown & Checkout Button */}
          {cart.length > 0 && (
            <div className="p-6 border-t border-stone-200 bg-[#FAF9F5] space-y-3">
              <div className="space-y-1.5 text-xs text-stone-600">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="tabular-nums font-mono text-stone-900">₹{cartSubtotal}</span>
                </div>
                {cartDiscount > 0 && (
                  <div className="flex justify-between text-emerald-800">
                    <span>Loyalty / Promotional Credit</span>
                    <span className="tabular-nums font-mono">-₹{cartDiscount}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Climate-Neutral Shipping</span>
                  <span className="tabular-nums font-mono">
                    {cartShipping === 0 ? 'Complimentary' : `₹${cartShipping}`}
                  </span>
                </div>
                <div className="flex justify-between text-sm font-semibold text-stone-900 pt-2 border-t border-stone-200">
                  <span>Estimated Total</span>
                  <span className="tabular-nums font-mono">₹{cartTotal}</span>
                </div>
              </div>

              <button
                onClick={handleStartCheckout}
                className="w-full py-3.5 bg-stone-900 text-white text-xs uppercase tracking-widest font-semibold hover:bg-stone-800 transition-colors flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Proceed to Secure Checkout</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <div className="flex items-center justify-center gap-2 text-[11px] text-stone-500 pt-1">
                <ShieldCheck className="w-3.5 h-3.5 text-stone-700" />
                <span>256-Bit SSL Encrypted & 30-Day Pure Shade Guarantee</span>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
