import React, { useState } from 'react';
import { ShoppingBag, Bell, Menu, X, Sparkles, Volume2, VolumeX } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { NotificationCenter } from './NotificationCenter';
import { sound } from '../utils/audio';

export const Navbar: React.FC = () => {
  const {
    currentPage,
    setCurrentPage,
    cartCount,
    setIsCartOpen,
    unreadNotificationCount,
    loyaltyPoints,
    setIsShadeMixerOpen,
    isSoundEnabled,
    toggleSound
  } = useApp();

  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Atelier' },
    { id: 'shop', label: 'Collection' },
    { id: 'tryon', label: 'Virtual Studio' },
    { id: 'diagnostic', label: 'Skin Diagnostic' },
    { id: 'loyalty-orders', label: 'Glow & Orders' }
  ];

  const handleNav = (id: string) => {
    sound.playClick();
    setCurrentPage(id);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF9F5]/95 backdrop-blur-md border-b border-stone-200">
      {/* Top micro announcement bar */}
      <div className="bg-stone-900 text-stone-100 text-[11px] py-1.5 px-4 text-center tracking-widest uppercase font-medium flex items-center justify-center gap-2">
        <span>Complimentary Climate-Neutral Express Shipping across India on all orders over ₹1,999</span>
        <span className="hidden md:inline text-stone-500">·</span>
        <span className="hidden md:inline text-stone-400">Fresh Lab Batch 04/26</span>
      </div>

      {/* Main Top Bar Contract: 3 Zones */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between">
        {/* Zone 1: Single text element wordmark in display face */}
        <button
          onClick={() => handleNav('home')}
          className="text-left group cursor-pointer focus:outline-none"
        >
          <span className="font-editorial text-2xl sm:text-3xl tracking-[0.25em] font-medium text-stone-900 uppercase">
            Aura
          </span>
        </button>

        {/* Zone 2: 4-6 clean text navigation links */}
        <nav className="hidden lg:flex items-center gap-8 text-[13px] tracking-wider uppercase font-medium text-stone-600">
          {navItems.map(item => {
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`relative py-1 transition-colors hover:text-stone-900 cursor-pointer whitespace-nowrap ${
                  isActive ? 'text-stone-950 font-semibold' : ''
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-stone-900" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: 1-2 primary actions */}
        <div className="flex items-center gap-2 sm:gap-3 relative">
          {/* Pigment Alchemy Mixer trigger */}
          <button
            onClick={() => {
              sound.playClick();
              setIsShadeMixerOpen(true);
            }}
            className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 border border-stone-300 text-stone-800 text-[11px] uppercase tracking-wider font-semibold hover:border-stone-900 hover:bg-stone-50 transition-colors cursor-pointer"
            title="Custom Shade Mixing Lab"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-700" />
            <span>Mixer</span>
          </button>

          {/* Sound Feedback toggle */}
          <button
            onClick={toggleSound}
            aria-label="Toggle haptic audio"
            className="p-2 text-stone-500 hover:text-stone-900 transition-colors cursor-pointer hidden md:block"
            title={isSoundEnabled ? 'Audio Feedback Active' : 'Audio Feedback Muted'}
          >
            {isSoundEnabled ? <Volume2 className="w-4 h-4 stroke-[1.5]" /> : <VolumeX className="w-4 h-4 stroke-[1.5] text-stone-400" />}
          </button>

          {/* Push notification toggle */}
          <div className="relative">
            <button
              onClick={() => {
                sound.playClick();
                setIsNotifOpen(prev => !prev);
              }}
              aria-label="Atelier alerts"
              className="p-2 text-stone-700 hover:text-stone-950 transition-colors relative cursor-pointer"
            >
              <Bell className="w-5 h-5 stroke-[1.5]" />
              {unreadNotificationCount > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-stone-900 border-2 border-[#FAF9F5]" />
              )}
            </button>
            <NotificationCenter isOpen={isNotifOpen} onClose={() => setIsNotifOpen(false)} />
          </div>

          {/* Bag button */}
          <button
            onClick={() => {
              sound.playClick();
              setIsCartOpen(true);
            }}
            className="flex items-center gap-2 px-3 sm:px-4 py-2 bg-stone-900 text-white text-xs tracking-wider uppercase font-medium hover:bg-stone-800 transition-colors cursor-pointer"
          >
            <ShoppingBag className="w-4 h-4 stroke-[1.75]" />
            <span className="hidden sm:inline">Bag</span>
            <span className="tabular-nums font-mono text-[11px] bg-stone-800 px-1.5 py-0.5 rounded-xs">
              {cartCount}
            </span>
          </button>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileMenuOpen(prev => !prev)}
            aria-label="Toggle menu"
            className="lg:hidden p-2 text-stone-800 hover:text-stone-950 cursor-pointer"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Nav Overlay */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-stone-200 bg-[#FAF9F5] px-6 py-6 space-y-4">
          <div className="flex flex-col space-y-3">
            {navItems.map(item => (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={`text-left text-sm uppercase tracking-widest py-2 transition-colors ${
                  currentPage === item.id ? 'font-semibold text-stone-900' : 'text-stone-600'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          <div className="pt-4 border-t border-stone-200 flex items-center justify-between text-xs text-stone-600">
            <button
              onClick={() => {
                setIsShadeMixerOpen(true);
                setMobileMenuOpen(false);
              }}
              className="flex items-center gap-1.5 text-stone-900 font-semibold"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-700" />
              <span>Launch Pigment Mixer</span>
            </button>
            <span className="text-xs text-stone-500 tabular-nums">
              {loyaltyPoints} pts
            </span>
          </div>
        </div>
      )}
    </header>
  );
};
