import React, { useState } from 'react';
import { ArrowRight, ShieldCheck, Heart, Sparkles, Check } from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Footer: React.FC = () => {
  const { setCurrentPage } = useApp();
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubscribed(true);
    setEmail('');
  };

  return (
    <footer className="bg-[#1C1917] text-stone-300 border-t border-stone-800">
      {/* Purity & Values Bar */}
      <div className="border-b border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 grid grid-cols-2 md:grid-cols-4 gap-6 text-center md:text-left">
          <div className="space-y-1">
            <h4 className="text-xs uppercase tracking-widest font-semibold text-stone-100">
              100% Purity Certified
            </h4>
            <p className="text-xs text-stone-400">Zero silicones, parabens, or synthetic dyes</p>
          </div>
          <div className="space-y-1">
            <h4 className="text-xs uppercase tracking-widest font-semibold text-stone-100">
              Virtual Shade Guarantee
            </h4>
            <p className="text-xs text-stone-400">Free shade exchange within 30 days of receipt</p>
          </div>
          <div className="space-y-1">
            <h4 className="text-xs uppercase tracking-widest font-semibold text-stone-100">
              Climate-Neutral Transit
            </h4>
            <p className="text-xs text-stone-400">100% carbon-offset courier deliveries</p>
          </div>
          <div className="space-y-1">
            <h4 className="text-xs uppercase tracking-widest font-semibold text-stone-100">
              Fresh Micro-Batched
            </h4>
            <p className="text-xs text-stone-400">Formulated in limited runs to protect bio-actives</p>
          </div>
        </div>
      </div>

      {/* Main Footer Links */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 grid grid-cols-1 md:grid-cols-5 gap-12">
        {/* Brand Column */}
        <div className="md:col-span-2 space-y-4">
          <span className="font-editorial text-2xl tracking-[0.25em] font-semibold text-white uppercase block">
            Aura
          </span>
          <p className="text-xs text-stone-400 leading-relaxed max-w-sm">
            Clean, high-performance cosmetic atelier blending dermatological botanicals with luminous mineral pigments. Engineered for all skin tones and sensitive barriers.
          </p>

          <form onSubmit={handleSubscribe} className="pt-2 max-w-sm space-y-2">
            <span className="text-[11px] uppercase tracking-wider font-semibold text-stone-200 block">
              Join The Atelier Circle
            </span>
            <div className="flex">
              <input
                type="email"
                required
                placeholder="Enter email for +50 Glow Points"
                value={email}
                onChange={e => setEmail(e.target.value)}
                className="bg-stone-900 border border-stone-700 text-stone-100 px-3 py-2 text-xs flex-1 focus:outline-none focus:border-stone-400"
              />
              <button
                type="submit"
                className="bg-stone-100 text-stone-900 px-4 py-2 text-xs uppercase tracking-wider font-semibold hover:bg-white transition-colors"
              >
                Join
              </button>
            </div>
            {subscribed && (
              <p className="text-xs text-emerald-400 flex items-center gap-1">
                <Check className="w-3.5 h-3.5" /> Welcome to the circle. +50 Glow points credited.
              </p>
            )}
          </form>
        </div>

        {/* Column 2: Navigation */}
        <div className="space-y-3">
          <h4 className="text-xs uppercase tracking-widest font-semibold text-stone-100">
            Atelier Navigation
          </h4>
          <ul className="space-y-2 text-xs text-stone-400">
            <li>
              <button onClick={() => setCurrentPage('home')} className="hover:text-white transition-colors cursor-pointer">
                Campaign & Editorial
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentPage('shop')} className="hover:text-white transition-colors cursor-pointer">
                The Product Catalog
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentPage('tryon')} className="hover:text-white transition-colors cursor-pointer">
                Virtual Try-On Studio
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentPage('diagnostic')} className="hover:text-white transition-colors cursor-pointer">
                Skin Tone Diagnostic
              </button>
            </li>
            <li>
              <button onClick={() => setCurrentPage('loyalty-orders')} className="hover:text-white transition-colors cursor-pointer">
                Glow Club & Live Tracking
              </button>
            </li>
          </ul>
        </div>

        {/* Column 3: Ingredient Philosophy */}
        <div className="space-y-3">
          <h4 className="text-xs uppercase tracking-widest font-semibold text-stone-100">
            Ingredient Standards
          </h4>
          <ul className="space-y-2 text-xs text-stone-400">
            <li>Ethical Plant Squalane</li>
            <li>Non-Nano Mineral Pigments</li>
            <li>Cold-Pressed Rosehip Extract</li>
            <li>Bio-Identical Ceramides</li>
            <li>Organic Damask Rose Water</li>
          </ul>
        </div>

        {/* Column 4: Customer Care */}
        <div className="space-y-3">
          <h4 className="text-xs uppercase tracking-widest font-semibold text-stone-100">
            Client Concierge
          </h4>
          <ul className="space-y-2 text-xs text-stone-400">
            <li>Complimentary Returns</li>
            <li>Live Color Consultations</li>
            <li>Global Shipping Inquiries</li>
            <li>Atelier Press Desk</li>
          </ul>
        </div>
      </div>

      {/* Copyright */}
      <div className="border-t border-stone-800 py-6 text-center text-xs text-stone-500">
        <p>© 2026 AURA Beauty Atelier Inc. All rights reserved. Clean Cosmetics Architecture.</p>
      </div>
    </footer>
  );
};
